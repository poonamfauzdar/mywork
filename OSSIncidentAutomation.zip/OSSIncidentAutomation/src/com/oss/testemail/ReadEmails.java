package com.oss.testemail;

import java.util.Properties;
import java.util.Map;
import java.util.HashMap;

import javax.mail.AuthenticationFailedException;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.FolderNotFoundException;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.ReadOnlyFolderException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.StoreClosedException;
import javax.mail.internet.InternetAddress;

public class ReadEmails {
	static Map<String, String> tMessages = new HashMap<String, String>();

	public ReadEmails() {
		processMail();
		getMaps();
	}

	public static void main(String g[]) {
		ReadEmails r = new ReadEmails();
		r.processMail();
	}
	// Q: I want to delete messages on a POP3 server. I set the DELETED flag on
	// those messages. Then I call the expunge() method, but I get a
	// MethodNotSupportedException. How do I delete messages when I use Sun's
	// POP3 provider?
	// A: The expunge() method is not supported by the POP3 provider. Instead,
	// after marking the messages to be deleted by setting the DELETED flag on
	// those messages, close the folder with the expunge flag set to true. That
	// is, invoke folder.close(true).

	private void printData(String data) {
		// log.info(data);
		System.out.println(data);
	}

	public void processMail() {
		Session session = null;
		Store store = null;
		Folder folder = null;
		Message message = null;
		Message[] messages = null;
		Object messagecontentObject = null;
		String sender = null;
		String subject = null;
		Multipart multipart = null;
		Part part = null;
		String contentType = null;

		try {
			printData("--------------processing mails started-----------------");
			Properties props = System.getProperties();
			props.put("mail.pop3s.connectiontimeout", "60000");
			props.put("mail.pop3s.timeout", "120000");
			session = Session.getDefaultInstance(props, null);

			// session = Session.getDefaultInstance(System.getProperties(),
			// null);

			printData("getting the session for accessing email.");
			// store = session.getStore("pop3");
			store = session.getStore("pop3s");
			store.connect("mail.cvshealth.com/owa", "CSAEMAIL", "Csa3Ma1l");
			printData("Connection established with POP3 server.");

			folder = store.getDefaultFolder();

			printData("Getting the Inbox folder.");

			folder = folder.getFolder("Inbox");

			folder.open(Folder.READ_WRITE);

			messages = folder.getMessages();

			for (int messageNumber = 0; messageNumber < messages.length; messageNumber++) {

				message = messages[messageNumber];

				messagecontentObject = message.getContent();

				if (messagecontentObject instanceof Multipart) {
					printData("Found Email with Attachment");
					sender = ((InternetAddress) message.getFrom()[0]).getPersonal();

					printData(
							"If the personal information has no entry, check the address for the sender information.");

					if (sender == null) {
						sender = ((InternetAddress) message.getFrom()[0]).getAddress();
						printData("sender in NULL. Printing Address:" + sender);
					}
					printData("Sender -." + sender);

					subject = message.getSubject();

					printData("subject=" + subject);

					multipart = (Multipart) message.getContent();

					printData("Retrieve the Multipart object from the message");

					for (int i = 0; i < multipart.getCount(); i++) {

						part = multipart.getBodyPart(i);

						contentType = part.getContentType();

						printData("Content: " + contentType);

						if (contentType.startsWith("text/plain")) {
							printData("---------reading content type text/plain  mail -------------");

							getSubjects(subject, part.getDescription());
						} else {

							String fileName = part.getFileName();
							printData("retrive the fileName=" + fileName);
						}
					}
				} else {
					printData("Found Mail Without Attachment");
					sender = ((InternetAddress) message.getFrom()[0]).getPersonal();

					printData(
							"If the personal information has no entry, check the address for the sender information.");

					if (sender == null) {
						sender = ((InternetAddress) message.getFrom()[0]).getAddress();
						printData("sender in NULL. Printing Address:" + sender);
					}

					subject = message.getSubject();
					// calling getSubjects;
					getSubjects(subject, "");
					printData("subject=" + subject);
				}
			}

			folder.close(true);
			store.close();
		}

		catch (AuthenticationFailedException e) {
			printData("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (FolderClosedException e) {
			printData("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (FolderNotFoundException e) {
			printData("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (NoSuchProviderException e) {
			printData("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (ReadOnlyFolderException e) {
			printData("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (StoreClosedException e) {
			printData("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (Exception e) {
			printData("Not able to process the mail reading.");
			e.printStackTrace();
		}
	}

	/*
	 * public static void main(String args[]) { ReadEmails readMail = new
	 * ReadEmails(); readMail.processMail(); readMail.getMaps(); }
	 */
	static void getSubjects(String sub, String content) {
		tMessages.put(sub, content);
	}

	// return tMessages;
	Map<String, String> getMaps() {
		return tMessages;
	}

}
