package com.oss.testemail;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.AuthenticationFailedException;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.FolderNotFoundException;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.ReadOnlyFolderException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.StoreClosedException;
import javax.mail.internet.InternetAddress;

public class TestEmailReader {
	static Map<String, String> tMessages = new HashMap<String, String>();

	public static void ReadEmail() {
		try {
			Session session = null;
			Store store = null;
			Folder folder = null;
			Message message = null;
			Message[] messages = null;
			Object messagecontentObject = null;
			String sender = null;
			String subject = null;
			Multipart multipart = null;
			Part part = null;
			String contentType = null;

			System.out.println("---------------------Reading Emails -------------------------");
			Properties props = System.getProperties();
			// props.put("mail.pop3.host", "mail.cvshealth.com/owa/");
			/*
			 * props.put("mail.pop3.connectiontimeout", "60000");
			 * props.put("mail.pop3.timeout", "120000"); //
			 * props.put("mail.pop3." , 0 );
			 * props.put("mail.pop3.starttls.enable", "true");
			 * props.put("mail.pop3.socketFactory.class" ,
			 * "javax.net.ssl.SSLSocketFactory"); //
			 * props.put("mail.pop3.sslPort" , sslPort);
			 * 
			 * 
			 */ props.put("mail.pop3.host", "pop.cvshealth.com");
			props.put("mail.pop3.port", "995");
			props.put("mail.pop3.starttls.enable", "true");

			session = Session.getDefaultInstance(props, null);
			store = session.getStore("pop3s");
			/*
			 * session = Session.getDefaultInstance(props, new
			 * javax.mail.Authenticator() { protected PasswordAuthentication
			 * getPasswordAuthentication() { return new
			 * PasswordAuthentication(Constants.EMAIL_FROM,password); } });
			 */
			/*
			 * store.connect("paz1trendvip","asaxena2@corp.cvs.com","Monday$7");
			 */
			// "cvsexbpd1.corp.cvs.com","CSAEMAIL","Csa3Ma1l"
			store.connect("pop.cvshealth.com", "cvs\\asaxena2", "Monday$7");
			System.out.println("Connection established with POP3s server.");

			folder = store.getDefaultFolder();

			System.out.println("Getting the Inbox folder.");

			folder = folder.getFolder("Inbox");

			folder.open(Folder.READ_WRITE);

			messages = folder.getMessages();
			for (int messageNumber = 0; messageNumber < 5; messageNumber++) {

				message = messages[messageNumber];

				messagecontentObject = message.getContent();

				if (messagecontentObject instanceof Multipart) {
					System.out.println("Found Email with Attachment");
					sender = ((InternetAddress) message.getFrom()[0]).getPersonal();

					System.out.println(
							"If the personal information has no entry, check the address for the sender information.");

					if (sender == null) {
						sender = ((InternetAddress) message.getFrom()[0]).getAddress();
						System.out.println("sender in NULL. Printing Address:" + sender);
					}
					System.out.println("Sender -." + sender);

					subject = message.getSubject();

					System.out.println("subject=" + subject);

					multipart = (Multipart) message.getContent();

					System.out.println("Retrieve the Multipart object from the message");

					for (int i = 0; i < multipart.getCount(); i++) {

						part = multipart.getBodyPart(i);

						contentType = part.getContentType();

						System.out.println("Content: " + contentType);

						if (contentType.startsWith("text/plain")) {
							System.out.println("---------reading content type text/plain  mail -------------");

							getSubjects(subject, part.getDescription());
						} else {

							String fileName = part.getFileName();
							System.out.println("retrive the fileName=" + fileName);
						}
					}
				} else {
					System.out.println("Found Mail Without Attachment");
					sender = ((InternetAddress) message.getFrom()[0]).getPersonal();

					System.out.println(
							"If the personal information has no entry, check the address for the sender information.");

					if (sender == null) {
						sender = ((InternetAddress) message.getFrom()[0]).getAddress();
						System.out.println("sender in NULL. Printing Address:" + sender);
					}

					subject = message.getSubject();
					// calling getSubjects;
					getSubjects(subject, "");
					System.out.println("subject=" + subject);
				}
			}

			folder.close(true);
			store.close();
		}

		catch (AuthenticationFailedException e) {
			System.out.println("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (FolderClosedException e) {
			System.out.println("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (FolderNotFoundException e) {
			System.out.println("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (NoSuchProviderException e) {
			System.out.println("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (ReadOnlyFolderException e) {
			System.out.println("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (StoreClosedException e) {
			System.out.println("Not able to process the mail reading.");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Not able to process the mail reading.");
			e.printStackTrace();
		}
	}

	static void getSubjects(String sub, String content) {
		tMessages.put(sub, content);
	}
}
