package com.oss.testemail;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class UrlValidate {
	public static void main(String args[]) throws Exception {
		System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		String[] hostList = { "https://prd1-csr-101.cvs.com/agent/",
				"https://edo.corp.cvshealth.com/EventDrivenOutreach/home",
				"http://cellmanager.cvs.com:8088/login_cells.asp", "https://prd1-merch-101/atg/bcc", "https://rri2atgcap1l1a:9443/CVSApp/home.jsp" };

		for (int i = 0; i < hostList.length; i++) {

			String url = hostList[i];
			getStatus(url);

		}

		System.out.println("Task completed...");
	}

	public static String getStatus(String url) throws IOException {

		String result = "";
		int code = 200;
		try {
			URL siteURL = new URL(url);
			System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
			HttpURLConnection connection = (HttpURLConnection) siteURL.openConnection();
			connection.setRequestMethod("GET");
			connection.setConnectTimeout(3000);
			connection.connect();

			code = connection.getResponseCode();
			if (code == 200) {
				result = "-> Green <-\t" + "Code: " + code;
				;
			} else {
				result = "-> Yellow <-\t" + "Code: " + code;
			}
		} catch (Exception e) {
			result = "-> Red <-\t" + "Wrong domain - Exception: " + e.getMessage();

		}
		System.out.println(url + "\t\tStatus:" + result);
		return result;
	}

}
