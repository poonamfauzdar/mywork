package com.oss.mail.quartz.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
//import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
//import org.springframework.transaction.PlatformTransactionManager;

import com.oss.mail.quartz.job.IncidentAutomationJob;

@Configuration
public class QuartzConfig {

	static Logger log = LogManager.getLogger(QuartzConfig.class.getName());
	Properties prop = new Properties();
	ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
	InputStream input = classLoader.getResourceAsStream("app.properties");

	// @Autowired
	// private DataSource dataSource;
	//
	// @Autowired
	// private PlatformTransactionManager transactionManager;

	@Autowired
	private ApplicationContext applicationContext;

	@PostConstruct
	public boolean init() {
		log.info("----------------------------QuartzConfig initialized.----------------------");
		quartzScheduler().start();
		return true;
	}

	public boolean schdulerPause() {
		log.info("----------------------------Scheduler Pausing.----------------------");
		quartzScheduler().stop();
		return true;
	}

	@Bean
	public SchedulerFactoryBean quartzScheduler() {
		SchedulerFactoryBean quartzScheduler = new SchedulerFactoryBean();

		// quartzScheduler.setDataSource(dataSource);
		// quartzScheduler.setTransactionManager(transactionManager);
		quartzScheduler.setOverwriteExistingJobs(true);
		quartzScheduler.setSchedulerName("OSSIncidentAutomation-quartz-scheduler");

		// custom job factory of spring with DI support for @Autowired!
		AutowiringSpringBeanJobFactory jobFactory = new AutowiringSpringBeanJobFactory();
		jobFactory.setApplicationContext(applicationContext);
		quartzScheduler.setJobFactory(jobFactory);

		quartzScheduler.setQuartzProperties(quartzProperties());

		Trigger[] triggers = { procesoMQTrigger().getObject() };
		quartzScheduler.setTriggers(triggers);

		return quartzScheduler;
	}

	@Bean
	public JobDetailFactoryBean procesoMQJob() {
		JobDetailFactoryBean jobDetailFactory = new JobDetailFactoryBean();
		jobDetailFactory.setJobClass(IncidentAutomationJob.class);
		jobDetailFactory.setGroup("spring4-quartz");
		return jobDetailFactory;
	}

	@Bean
	public CronTriggerFactoryBean procesoMQTrigger() {
		try {
			prop.load(input);
		} catch (IOException e) {
			log.error(e.getMessage(), e);
		}
		String scheduleTime = prop.getProperty("Quartz.job.IncidentAutomationJob.cron");
		CronTriggerFactoryBean cronTriggerFactoryBean = new CronTriggerFactoryBean();
		cronTriggerFactoryBean.setJobDetail(procesoMQJob().getObject());
		cronTriggerFactoryBean.setCronExpression(scheduleTime);
		cronTriggerFactoryBean.setGroup("spring4-quartz");
		return cronTriggerFactoryBean;
	}

	@Bean
	public Properties quartzProperties() {
		PropertiesFactoryBean propertiesFactoryBean = new PropertiesFactoryBean();
		propertiesFactoryBean.setLocation(new ClassPathResource("/quartz.properties"));
		Properties properties = null;
		try {
			propertiesFactoryBean.afterPropertiesSet();
			properties = propertiesFactoryBean.getObject();

		} catch (IOException e) {
			log.warn("Cannot load quartz.properties.");
		}

		return properties;
	}

	@PreDestroy
	public boolean destroy() {
		log.info("------------------Scheduler Stopping --------------");
		try {
			quartzScheduler().getScheduler().shutdown(true);
		} catch (SchedulerException e) {
			log.error(e.getMessage(), e);
		}
		return true;
	}
}