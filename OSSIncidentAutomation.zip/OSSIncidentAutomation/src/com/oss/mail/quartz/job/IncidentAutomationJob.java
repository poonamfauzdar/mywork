package com.oss.mail.quartz.job;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.InterruptableJob;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.UnableToInterruptJobException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oss.mail.service.EmailReadingService;
import com.oss.mail.beans.TaskDetails;

@Service
@Transactional
@DisallowConcurrentExecution
public class IncidentAutomationJob implements Job, InterruptableJob {
	static Logger logger = LogManager.getLogger(IncidentAutomationJob.class.getName());
	List<TaskDetails> response = new ArrayList<TaskDetails>();
	@Autowired
	private EmailReadingService emailReadingService;

	@Override
	public void interrupt() throws UnableToInterruptJobException {
		logger.info("IncidentAutomationJob is interrupted");
		logger.error("IncidentAutomationJob is interrupted");
	}

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		try {
			String timeStamp = new SimpleDateFormat("MM-dd-yyyy HH:mm").format(Calendar.getInstance().getTime());
			logger.info("Job Execution Started at : " + timeStamp);
			logger.info("Calling readEmail() from execute() of IncidentAutomationJob");
			emailReadingService.readEmails();
			logger.info("Successfully Processed Alerts, now exiting.");
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

}
