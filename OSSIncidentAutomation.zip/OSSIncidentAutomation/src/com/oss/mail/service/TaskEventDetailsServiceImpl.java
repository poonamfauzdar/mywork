package com.oss.mail.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oss.mail.beans.TaskEventDetails;
import com.oss.mail.dao.TaskEventDetailsDAO;;

@Service
public class TaskEventDetailsServiceImpl implements TaskEventDetailsService {

	@Autowired
	private TaskEventDetailsDAO taskEventDetailsDao;

	@Transactional
	@Override
	public TaskEventDetails addTaskEventDetails(TaskEventDetails taskEventDetails) {
		return taskEventDetailsDao.addTaskEventDetails(taskEventDetails);
	}

	@Transactional
	@Override
	public TaskEventDetails updateTaskEventDetails(TaskEventDetails taskEventDetails) {
		return taskEventDetailsDao.updateTaskEventDetails(taskEventDetails);
	}

	@Transactional
	@Override
	public List<TaskEventDetails> listTaskEventDetails() {
		return taskEventDetailsDao.listTaskEventDetails();
	}

	@Transactional
	@Override
	public TaskEventDetails getTaskEventDetailsById(Integer ted_task_id) {
		return taskEventDetailsDao.getTaskEventDetailsById(ted_task_id);
	}

	@Transactional
	@Override
	public void removeTaskEventDetails(Integer ted_task_id) {
		taskEventDetailsDao.removeTaskEventDetails(ted_task_id);
	}

}
