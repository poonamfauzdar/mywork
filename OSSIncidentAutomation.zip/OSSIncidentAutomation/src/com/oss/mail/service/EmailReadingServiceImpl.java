package com.oss.mail.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oss.mail.dao.EmailReadingDAO;
import com.oss.mail.beans.TaskDetails;

@Service
public class EmailReadingServiceImpl implements EmailReadingService {
	static Logger logger = LogManager.getLogger(EmailReadingServiceImpl.class.getName());

	@Autowired
	EmailReadingDAO emailReadingDAO;

	@Override
	public List<TaskDetails> readEmails() {
		logger.info("Called readEmail() from EmailReadingServiceImpl");
		logger.info("Calling readEmailDao() from EmailReadingDAO");
		return emailReadingDAO.readEmailDao();
	}
}
