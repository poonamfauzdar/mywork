package com.oss.mail.service;

import java.util.List;

import com.oss.mail.beans.TaskDetails;

public interface TaskDetailsService {

	public TaskDetails addTaskDetails(TaskDetails taskDetails);

	public TaskDetails updateTaskDetails(TaskDetails taskDetails);

	public List<TaskDetails> listTaskDetails();

	public TaskDetails getTaskDetailsById(Integer tdt_task_id);

	public void removeTaskDetails(Integer tdt_task_id);
}
