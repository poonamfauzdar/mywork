package com.oss.mail.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oss.mail.beans.TaskDetails;
import com.oss.mail.dao.TaskDetailsDao;

@Service
public class TaskDetailsServiceImpl implements TaskDetailsService {

	@Autowired
	private TaskDetailsDao taskDetailsDao;

	@Transactional
	@Override
	public TaskDetails addTaskDetails(TaskDetails taskDetails) {
		return taskDetailsDao.addTaskDetails(taskDetails);
	}

	@Transactional
	@Override
	public TaskDetails updateTaskDetails(TaskDetails taskDetails) {
		return taskDetailsDao.updateTaskDetails(taskDetails);
	}

	@Transactional
	@Override
	public List<TaskDetails> listTaskDetails() {
		return taskDetailsDao.listTaskDetails();
	}

	@Transactional
	@Override
	public TaskDetails getTaskDetailsById(Integer tdt_task_id) {
		return taskDetailsDao.getTaskDetailsById(tdt_task_id);
	}

	@Transactional
	@Override
	public void removeTaskDetails(Integer tdt_task_id) {
		taskDetailsDao.removeTaskDetails(tdt_task_id);
	}

}
