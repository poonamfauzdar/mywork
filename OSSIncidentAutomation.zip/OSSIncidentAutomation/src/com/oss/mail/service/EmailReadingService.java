package com.oss.mail.service;

import java.util.List;

import com.oss.mail.beans.TaskDetails;

public interface EmailReadingService {

	public List<TaskDetails> readEmails();
}
