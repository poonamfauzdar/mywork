package com.oss.mail.service;

import java.util.List;

import com.oss.mail.beans.TaskEventDetails;

public interface TaskEventDetailsService {

	public TaskEventDetails addTaskEventDetails(TaskEventDetails TaskEventDetails);

	public TaskEventDetails updateTaskEventDetails(TaskEventDetails TaskEventDetails);

	public List<TaskEventDetails> listTaskEventDetails();

	public TaskEventDetails getTaskEventDetailsById(Integer ted_task_id);

	public void removeTaskEventDetails(Integer ted_task_id);
}
