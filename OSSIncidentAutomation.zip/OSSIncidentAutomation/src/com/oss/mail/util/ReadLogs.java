package com.oss.mail.util;

import java.io.File;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.nio.file.Files;

import org.apache.commons.io.input.ReversedLinesFileReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.oss.mail.dao.EmailReadingDAOImpl;

public class ReadLogs {
	static Logger logger = LogManager.getLogger(EmailReadingDAOImpl.class.getName());
	public static boolean extractLogs(int noOfLines, String logFileLocation, String outputFileLocation){
		logger.info("Called extractLogs(");
		try{
		int counter = 0; 
		List<String> dataList=new ArrayList<String>();
		StringBuffer content=new StringBuffer();
		ReversedLinesFileReader object = new ReversedLinesFileReader(new File(logFileLocation));
		while(counter < noOfLines) {
		    dataList.add(object.readLine());
		    counter++;
		}
		object.close();
		Collections.reverse(dataList);
		dataList.forEach(data-> {
			content.append(data);
			content.append(System.getProperty("line.separator"));
		});
		String data=content.toString();
		Files.write(Paths.get(outputFileLocation), data.getBytes());
		return true;
		}catch(Exception e){
			
		}
		return false;
	} 
	public static void main(String[] args) {
		System.out.println("Reading and Extracting logs ....");
		extractLogs(15, "\\\\CVSCIFSP03\\MIS_Retail\\CVS_OSS\\Abhishek\\Eclipse Workspace\\OSSIncidentAutomation\\logs\\OSSIncidentAutomationLogs.2018-11-23.log", 
				"\\\\CVSCIFSP03\\MIS_Retail\\CVS_OSS\\Abhishek\\Eclipse Workspace\\OSSIncidentAutomation\\logs\\Extracted.log");
		System.out.println("Finished reading.");
	}
}
