package com.oss.mail.util;

import com.sun.crypto.provider.SunJCE;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class SecurityUtil {
	private static Cipher encryptCipher;
	private static Cipher decryptCipher;
	private static BASE64Encoder encoder = new BASE64Encoder();
	private static BASE64Decoder decoder = new BASE64Decoder();

	static {
		Security.addProvider(new SunJCE());

		char[] pass = "1QWE@#$RF%6J*K(FVBIASDFVBN".toCharArray();
		byte[] salt = { -93, 33, 36, 44, -14, -46, 62, 25 };
		int iterations = 3;
		init(pass, salt, iterations);
	}

	public static void init(char[] pass, byte[] salt, int iterations) throws SecurityException {
		try {
			PBEParameterSpec ps = new PBEParameterSpec(salt, 20);
			SecretKeyFactory kf = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
			SecretKey k = kf.generateSecret(new PBEKeySpec(pass));
			encryptCipher = Cipher.getInstance("PBEWithMD5AndDES/CBC/PKCS5Padding");
			encryptCipher.init(1, k, ps);
			decryptCipher = Cipher.getInstance("PBEWithMD5AndDES/CBC/PKCS5Padding");
			decryptCipher.init(2, k, ps);
		} catch (Exception e) {
			throw new SecurityException("Could not initialize CryptoLibrary: " + e.getMessage());
		}
	}

	public static synchronized String encrypt(String str) throws SecurityException {
		try {
			byte[] utf8 = str.getBytes("UTF8");
			byte[] enc = encryptCipher.doFinal(utf8);
			return encoder.encode(enc);
		} catch (Exception e) {
			throw new SecurityException("Could not encrypt: " + e.getMessage());
		}
	}

	public static synchronized String decrypt(String str) throws SecurityException {
		try {
			byte[] dec = decoder.decodeBuffer(str);
			byte[] utf8 = decryptCipher.doFinal(dec);
			return new String(utf8, "UTF8");
		} catch (Exception e) {
			throw new SecurityException("Could not decrypt: " + e.getMessage());
		} finally {
		}
	}

	public static void main(String[] args) {
		try {
			String user = "ISHD_RPT";
			String pass = "cvIP0ox28Dqis";
			String euser = encrypt(user);
			String epass = encrypt(pass);
			String duser = decrypt(euser);
			String dpass = decrypt(epass);
			String hpsmDBPass = decrypt("KpiCpgdM03MfHiJq+ImCVg==");
			System.out.println("HPSM pass" + hpsmDBPass);
			System.out.println("ASM DEV:" + epass);
			// System.out.println("ASM password
			// decypted"+decrypt("EDEGFp+tr1X0CLtXmRtyWg=="));
			// System.out.println("User: " + user + " --> " + euser + " --> " +
			// duser);
			// System.out.println("Pass: " + pass + " --> " + epass + " --> " +
			// dpass);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}