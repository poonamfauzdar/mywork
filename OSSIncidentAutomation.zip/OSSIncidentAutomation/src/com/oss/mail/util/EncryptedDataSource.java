package com.oss.mail.util;

import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class EncryptedDataSource extends DriverManagerDataSource {

	@Override
	public String getPassword() {
		String password = super.getPassword();
		return decode(password);
	}

	/***
	 * Decode Password
	 */
	private String decode(String decode) {
		try {
			// byte[] decodedValue =
			// DatatypeConverter.parseBase64Binary(decode);
			//// System.out.println("decoded password"+new String(decodedValue,
			// StandardCharsets.UTF_8));
			// return new String(decodedValue, StandardCharsets.UTF_8); // use
			// "utf-8" if java 6
			// }catch(Exception e){
			// e.printStackTrace();
			// }
			// return null;
			return SecurityUtil.decrypt(decode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}