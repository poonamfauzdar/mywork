package com.oss.mail.util;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.FolderNotFoundException;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.ReadOnlyFolderException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.StoreClosedException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage.RecipientType;

import org.apache.commons.lang.ArrayUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Repository;

@Repository
public class GetEmails {

	Session session = null;
	Store store = null;
	Folder folder = null;
	Message message = null;
	Message[] messages = null;
	Object messagecontentObject = null;
	String sender = null;
	String subject = null;
	Multipart multipart = null;
	Part part = null;
	String contentType = null;
	String body;

	Message[] exclusionEmails;
	Message[] processedEmails;

	static Map<String, String> tMessages = new HashMap<String, String>();

	// static Logger logger = Logger.getLogger(GetEmails.class.getName());
	static Logger logger = LogManager.getLogger(GetEmails.class.getName());

	@Bean
	public Map<String, String> getEmails(String host, String port, String username, String password, int NoOfEmails,
			String inputFolder, String splitter) {
		try {
			tMessages.clear();
			Properties props = System.getProperties();

			props.put("mail.imap.host", host);
			props.put("mail.imap.port", port);
			props.put("mail.imap.starttls.enable", "true");

			session = Session.getDefaultInstance(props, null);
			store = session.getStore("imaps");

			store.connect(host, username, password);

			logger.info("Connection established with IMAP server on host :" + host + " : " + port);
			folder = store.getDefaultFolder();

			logger.info("Getting the " + inputFolder + " folder.");
			folder = folder.getFolder(inputFolder);

			logger.info("Opening the " + inputFolder + " folder with READ_ONLY permission.");
			folder.open(Folder.READ_ONLY);
			logger.info("Opened the " + inputFolder + " folder.");

			logger.info("Getting the Emails from " + inputFolder + " folder.");
			messages = folder.getMessages();

			// SearchTerm term = null;
			//
			// Calendar cal = null;
			// cal = Calendar.getInstance();
			// Date minDate = new Date(cal.getTimeInMillis()); //get today date
			//
			// cal.add(Calendar.DAY_OF_MONTH, 1); //add 1 day
			// Date maxDate = new Date(cal.getTimeInMillis()); //get tomorrow
			// date
			// ReceivedDateTerm minDateTerm = new
			// ReceivedDateTerm(ComparisonTerm.GE, minDate);
			// ReceivedDateTerm maxDateTerm = new
			// ReceivedDateTerm(ComparisonTerm.LE, maxDate);
			//
			// term = new AndTerm(term, minDateTerm); //concat the search terms
			// term = new AndTerm(term, maxDateTerm);
			//
			// Message messages[] = folderInbox.search(term);
			//
			int EmailCount = 0;
			if (NoOfEmails == -1) {
				EmailCount = messages.length;
			} else {
				EmailCount = NoOfEmails;
			}
			logger.info("Total Number of Emails :" + messages.length);
			if (messages.length > 0) {
				logger.info("Email Details are below");
				for (int messageNumber = 0; messageNumber < EmailCount; messageNumber++) {

					message = messages[messageNumber];

					// messagecontentObject = message.getContent();

					sender = ((InternetAddress) message.getFrom()[0]).getAddress();

					logger.info("Sender is : " + sender);
					subject = message.getSubject();
					logger.info("Message " + messageNumber + " is :" + subject);

					// multipart = (Multipart) message.getContent();
					Address[] recipient = message.getRecipients(RecipientType.TO);
					// body = message.getContent().toString();
					// DateFormat readFormat = new SimpleDateFormat( "E MMM dd
					// HH:mm:ss z yyyy");
					// DateFormat writeFormat = new SimpleDateFormat(
					// "MM-dd-yyyy HH:mm:ss");
					// Date date = null;
					// try {
					// date =
					// readFormat.parse(message.getSentDate().toString());//Sat
					// Nov 10 12:49:21 EST 2018
					// } catch (ParseException e) {
					// e.printStackTrace();
					// }
					// String formattedDate=null;
					// if (date != null) {
					// formattedDate = writeFormat.format(date);
					// }
					// logger.info("Sent Date Prev :"+(String) (new
					// SimpleDateFormat("MM-dd-yyyy
					// HH:mm:ss").format(message.getSentDate())));
					// logger.info("Sent Date : "+formattedDate);
					body = ((String) (new SimpleDateFormat("MM-dd-yyyy HH:mm:ss").format(message.getSentDate()))) + splitter
							+ recipient[0].toString() + splitter + message.getSubject();
					// if(putEmails(message.getSubject(), body)){
					// logger.info("Marking Email as deleted.");
					// message.setFlag(Flags.Flag.DELETED, true);
					// }
					logger.info("Adding in Map.");
					putEmails(message.getSubject(), body);
				}

			} else {
				logger.info("There was no emails to process, hence exiting.");
			}
			logger.info("Closing the folder");
			folder.close(true);
			logger.info("Closing the store");
			store.close();
		} catch (FolderClosedException e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		} catch (FolderNotFoundException e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		} catch (NoSuchProviderException e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		} catch (ReadOnlyFolderException e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		} catch (StoreClosedException e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		} catch (Exception e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return tMessages;
	}

	@Bean
	static boolean putEmails(String sub, String content) {
		tMessages.put(sub, content);
		return true;
	}

	@Bean
	public boolean backUpAndRemoveEmails(List<String> processedMesseges, String host, String port, String username,
			String password, String inputFolder, String backupFolder, String exclusionFolder,
			List<String> exclusionList) {
		logger.info("processing starts for backup and remove the read emails");
		try {
			processedEmails = null;
			exclusionEmails = null;
			logger.info("Processed Message Length: " + processedMesseges.size());
			logger.info("Exclusion List Length: " + exclusionList.size());
			
			Properties props = System.getProperties();

			props.put("mail.imap.host", host);
			props.put("mail.imap.port", port);
			props.put("mail.imap.starttls.enable", "true");

			session = Session.getDefaultInstance(props, null);
			store = session.getStore("imaps");

			store.connect(host, username, password);

			logger.info("Connection established with IMAP server on host :" + host + " : " + port + ", Username : "
					+ username);
			folder = store.getDefaultFolder();

			logger.info("Getting the " + inputFolder + " folder.");
			folder = folder.getFolder(inputFolder);

			logger.info("Opening the " + inputFolder + " folder with READ_WRITE permission.");
			folder.open(Folder.READ_WRITE);
			logger.info("Opened the " + inputFolder + " folder.");

			logger.info("Getting the Emails from " + inputFolder + " folder.");
			messages = folder.getMessages();

			logger.info("Total Number of Emails :" + messages.length);
			if (messages.length > 0) {
				for (int messageNumber = 0; messageNumber < messages.length; messageNumber++) {

					message = messages[messageNumber];

					if (!exclusionList.isEmpty()) {
						logger.info("Checking for email in Exclusion list :" + message.getSubject());
						try {
							// if
							// (exclusionList.contains(message.getSubject().toString()))
							// {
							// logger.info("Email Exists in Exclusion list");
							// logger.info("Adding email to Exclusion Folder :"
							// + message.getSubject());
							// exclusionEmails = (Message[])
							// ArrayUtils.add(exclusionEmails, message);
							// logger.info("Marking Email as deleted : " +
							// message.getSubject());
							// message.setFlag(Flags.Flag.DELETED, true);
							//
							// } else {
							// logger.info("Email doesn't exist in Exclusion
							// List");
							// logger.info("Checking for Processed Email");
							// if
							// (processedMesseges.contains(message.getSubject().toString()))
							// {
							// logger.info("Email found to be processed.");
							// logger.info("Adding email to processed Email
							// Array.");
							// processedEmails = (Message[])
							// ArrayUtils.add(processedEmails, message);
							// logger.info("Marking Email as deleted : " +
							// message.getSubject());
							// message.setFlag(Flags.Flag.DELETED, true);
							// }
							//
							// }
							for (String excl : exclusionList) {
								if (message.getSubject().toString().contains(excl)) {
									logger.info("Email Exists in Exclusion list");
									logger.info("Adding email to Exclusion Folder :" + message.getSubject());
									exclusionEmails = (Message[]) ArrayUtils.add(exclusionEmails, message);
									logger.info("Marking Email as deleted : " + message.getSubject());
									message.setFlag(Flags.Flag.DELETED, true);
									break;
								} else {
									logger.info("Email doesn't exist in Exclusion List");
								}
							}
						} catch (MessagingException e1) {
							logger.error(e1.getMessage(), e1);
						}
					} else if (exclusionList.isEmpty()) {
						logger.info("Exclusion List was empty, so we are going ahead to check in processed list.");
					}
					logger.info("Checking in Processed Message List.");
					if (processedMesseges.contains(message.getSubject().toString())) {
						logger.info("Email found to be processed.");
						logger.info("Adding email to processed Email Array.");
						processedEmails = (Message[]) ArrayUtils.add(processedEmails, message);
						logger.info("Marking Email as deleted : " + message.getSubject());
						message.setFlag(Flags.Flag.DELETED, true);
					} else {
						logger.info("Email did not processed.");
					}
				}

				if (processedEmails != null) {
					logger.info("Copying " + processedEmails.length + " Processed Emails to " + backupFolder
							+ " Folder from " + inputFolder + " folder.");
					folder.copyMessages(processedEmails, store.getFolder(backupFolder));
				} else {
					logger.info("There is no emails to remove and backup for processed Emails.");
				}
				if (exclusionEmails != null) {
					logger.info("Copying " + exclusionEmails.length + " Exclusion Emails to " + exclusionFolder
							+ " Folder from " + inputFolder + " folder.");
					folder.copyMessages(exclusionEmails, store.getFolder(exclusionFolder));
				} else {
					logger.info("There is no emails to remove and backup for Exclusion Emails.");
				}

			} else {
				logger.info("There was no emails to process, hence exiting.");
			}
			logger.info("Closing the folder");
			folder.close(true);
			logger.info("Closing the store");
			store.close();

			return true;
		} catch (FolderClosedException e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		} catch (FolderNotFoundException e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		} catch (NoSuchProviderException e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		} catch (ReadOnlyFolderException e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		} catch (StoreClosedException e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		} catch (Exception e) {
			logger.error("Not able to process the mail reading.");
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return false;
	}
}
