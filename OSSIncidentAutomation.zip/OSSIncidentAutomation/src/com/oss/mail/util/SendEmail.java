package com.oss.mail.util;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.oss.mail.beans.TaskDetails;


public class SendEmail {
	
	static Logger logger = LogManager.getLogger(SendEmail.class.getName());
	static String ossDashboardLink;
	static String sendEmailHost;
	static String sendEmailFrom;
	static String sendEmailTo;
	static String sendEmailCc;

	static Properties prop = new Properties();
	static ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
	static InputStream input = classLoader.getResourceAsStream("app.properties");
	
	 public static String send(String host, String username, String password, String to, String cc, String sub, String msg) throws IOException{  
         //Get properties object    
   
         Properties props = new Properties();
         props.put("mail.smtp.host", host);
         props.put("mail.smtp.starttls.enable", "true");
         System.out.println("Host :"+host);
         //get Session   
         Session session = Session.getDefaultInstance(props,    
          new javax.mail.Authenticator() {    
          protected PasswordAuthentication getPasswordAuthentication() {    
          return new PasswordAuthentication(username ,password);  
          }    
         });    
         //compose message    
         try {    
        	 StringTokenizer strTok = new StringTokenizer(to, ";");
    	     int iEmailIdCount = 0;
    	     String[] emailIds = new String[strTok.countTokens()];
    	     while (strTok.hasMoreTokens())
    	     {
    	       emailIds[iEmailIdCount] = strTok.nextToken();
    	       iEmailIdCount++;
    	     }
    	     StringTokenizer strTokcc = new StringTokenizer(cc, ";");
    	     int iccEmailIdCount = 0;
    	     String[] emailIdscc = new String[strTokcc.countTokens()];
    	     while (strTokcc.hasMoreTokens())
    	     {
    	       emailIdscc[iccEmailIdCount] = strTokcc.nextToken();
    	       iccEmailIdCount++;
    	     }
        	 InternetAddress[] addressTo = new InternetAddress[emailIds.length];
             for (int i = 0; i < emailIds.length; i++)
             {
               addressTo[i] = new InternetAddress(emailIds[i]);
             }
             InternetAddress[] addressCc = new InternetAddress[emailIdscc.length];
             for (int i = 0; i < emailIdscc.length; i++)
             {
               addressCc[i] = new InternetAddress(emailIdscc[i]);
             }
          MimeMessage message = new MimeMessage(session);    
          message.setRecipients(Message.RecipientType.CC,addressCc);
//          message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
          message.setRecipients(Message.RecipientType.TO, addressTo);
          message.setSubject(sub);    
          message.setFrom(new InternetAddress(username));
          message.setText(msg);  
          message.setContent(msg, "text/html; charset=utf-8");
          //send message  
          Transport.send(message);    
          System.out.println("message sent successfully"); 


          return "Success";
          
         } catch (MessagingException e) {throw new RuntimeException(e); }    
            
   }  
	 public static boolean sendSuccessNotification(List<TaskDetails> taskDetails) throws IOException{  
		 logger.info("Called sendSuccessNotification() to send Email for "+taskDetails.size()+" Alerts");
		 prop.load(input);
		 logger.info("Setting up environment.");
		 	ossDashboardLink = prop.getProperty("mail.sendMail.ossDashboardLink");
			sendEmailHost = prop.getProperty("mail.sendMail.smtp.host");
			sendEmailFrom = prop.getProperty("mail.sendEmail.from");
			sendEmailTo = prop.getProperty("mail.sendEmail.to");
			sendEmailCc = prop.getProperty("mail.sendMail.cc");
			
		 String timeStamp = new SimpleDateFormat("MMM dd yyyy HH:mm").format(Calendar.getInstance().getTime());
		 logger.info("Generating Email message.");
		 String sub="OSSIncidentAutomation report - "+taskDetails.size()+" Alert(s) have been processed : "+timeStamp;
		 logger.info("Subject of Email :"+sub);
		 logger.info("Creating Contents of Email body.");
		 String msg=createContent(taskDetails, ossDashboardLink);
         Properties props = new Properties();
         props.put("mail.smtp.host", sendEmailHost);
         props.put("mail.smtp.starttls.enable", "true");
         logger.info("Host :"+sendEmailHost);
         //get Session   
         Session session = Session.getInstance(props,    
          new javax.mail.Authenticator() {    
          protected PasswordAuthentication getPasswordAuthentication() {    
          return new PasswordAuthentication(sendEmailFrom ,"");  
          }    
         });    
         //compose message    
         try {    
        	 StringTokenizer strTok = new StringTokenizer(sendEmailTo, ";");
    	     int iEmailIdCount = 0;
    	     String[] emailIds = new String[strTok.countTokens()];
    	     while (strTok.hasMoreTokens())
    	     {
    	       emailIds[iEmailIdCount] = strTok.nextToken();
    	       iEmailIdCount++;
    	     }
    	     StringTokenizer strTokcc = new StringTokenizer(sendEmailCc, ";");
    	     int iccEmailIdCount = 0;
    	     String[] emailIdscc = new String[strTokcc.countTokens()];
    	     while (strTokcc.hasMoreTokens())
    	     {
    	       emailIdscc[iccEmailIdCount] = strTokcc.nextToken();
    	       iccEmailIdCount++;
    	     }
        	 InternetAddress[] addressTo = new InternetAddress[emailIds.length];
             for (int i = 0; i < emailIds.length; i++)
             {
               addressTo[i] = new InternetAddress(emailIds[i]);
             }
             InternetAddress[] addressCc = new InternetAddress[emailIdscc.length];
             for (int i = 0; i < emailIdscc.length; i++)
             {
               addressCc[i] = new InternetAddress(emailIdscc[i]);
             }
          MimeMessage message = new MimeMessage(session);    
          message.setRecipients(Message.RecipientType.CC,addressCc);
//          message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
          message.setRecipients(Message.RecipientType.TO, addressTo);
          message.setSubject(sub);    
          message.setFrom(new InternetAddress(sendEmailFrom));
          message.setText(msg);  
          message.setContent(msg, "text/html; charset=utf-8");
          //send message  
          logger.info("Sending Email..");
          Transport.send(message);    
          logger.info("Email sent successfully.");


          return true;
          
         } catch (MessagingException e) {throw new RuntimeException(e); }    
            
   }  
	 private static String createContent(List<TaskDetails> taskDetails, String ossDashboardLink) {
		 StringBuffer content=new StringBuffer();
		 //Adding Upper Part
		content.append(
				"<html xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\" xmlns=\"http://www.w3.org/TR/REC-html40\"><head><meta http-equiv=Content-Type content=\"text/html; charset=utf-8\"><meta name=Generator content=\"Microsoft Word 15 (filtered medium)\"><!--[if !mso]><style>v/:* {behavior:url(#default#VML);}"
						+ "o\"+':'+" + "* {behavior:url(#default#VML);}w\"+':'+"
						+ "* {behavior:url(#default#VML);}.shape {behavior:url(#default#VML);}</style><![endif]--><style><!--/* Font Definitions */@font-face{font-family:\"Cambria Math\";panose-1:2 4 5 3 5 4 6 3 2 4;}@font-face	{font-family:Calibri;	panose-1:2 15 5 2 2 2 4 3 2 4;}@font-face	{font-family:Verdana;	panose-1:2 11 6 4 3 5 4 4 2 4;}@font-face	{font-family:Cambria;	panose-1:2 4 5 3 5 4 6 3 2 4;}@font-face	{font-family:\"Century Gothic\";	panose-1:2 11 5 2 2 2 2 2 2 4;}@font-face	{font-family:\"Franklin Gothic Book\";	panose-1:2 11 5 3 2 1 2 2 2 4;}* Style Definitions */p.MsoNormal, li.MsoNormal, div.MsoNormal	{margin:0in;	margin-bottom:.0001pt;	font-size:12.0pt;	font-family:\"Times New Roman\",serif;}"
						+ "h4	{mso-style-priority:9;	mso-style-link:\"Heading 4 Char\";	mso-margin-top-alt:auto;	margin-right:0in;	mso-margin-bottom-alt:auto;	margin-left:0in;	font-size:12.0pt;	font-family:\"Times New Roman\",serif;	font-weight:bold;}a:link, span.MsoHyperlink	{mso-style-priority:99;	color:blue;	text-decoration:underline;}a:visited, span.MsoHyperlinkFollowed	{mso-style-priority:99;	color:purple;	text-decoration:underline;}p	{mso-style-priority:99;	mso-margin-top-alt:auto;	margin-right:0in;	mso-margin-bottom-alt:auto;	margin-left:0in;	font-size:12.0pt;	font-family:\"Times New Roman\",serif;}span.Heading4Char	{mso-style-name:\"Heading 4 Char\";	mso-style-priority:9;	mso-style-link:\"Heading 4\";font-family:\"Cambria\",serif;color:#365F91;	font-style:italic;}span.EmailStyle19"
						+ "	{mso-style-type:personal;	font-family:\"Calibri\",sans-serif;	color:windowtext;	font-weight:normal;	font-style:normal;	text-decoration:none none;}span.EmailStyle20	{mso-style-type:personal;	font-family:\"Calibri\",sans-serif;	color:windowtext;font-weight:normal;	font-style:normal;	text-decoration:none none;}span.EmailStyle21	{mso-style-type:personal-reply;	font-family:\"Calibri\",sans-serif;	color:#1F497D;}.MsoChpDefault	{mso-style-type:export-only;	font-size:10.0pt;}@page WordSection1	{size:8.5in 11.0in;	margin:1.0in 1.0in 1.0in 1.0in;}div.WordSection1	{page:WordSection1;}--></style><!--[if gte mso 9]><xml><o:shapedefaults v:ext=\"edit\" spidmax=\"1026\" /></xml><![endif]--><!--[if gte mso 9]><xml><o:shapelayout v:ext=\"edit\"><o:idmap v:ext=\"edit\" data=\"1\" /></o:shapelayout></xml><![endif]--></head><body lang=EN-US link=blue vlink=purple><div class=WordSection1><p class=MsoNormal><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'>Hi Team, <br><br>Following alert(s) have been processed.<o:p></o:p></span></p><p class=MsoNormal><o:p>&nbsp;</o:p></p><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style='border-collapse:collapse'>");
		// Adding Table Header
		content.append(
				"<tr style='height:5.75pt'><td valign=top style='border:solid #4F81BD 1.0pt;border-right:none;background:#4F81BD;padding:0in 5.4pt 0in 5.4pt;height:5.75pt'><p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:11.0pt;color:white'>ASM ID<o:p></o:p></span></b></p></td><td valign=top style='border-top:solid #4F81BD 1.0pt;border-left:none;border-bottom:solid #4F81BD 1.0pt;border-right:none;background:#4F81BD;padding:0in 5.4pt 0in 5.4pt;height:5.75pt'><p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:11.0pt;color:white'>Module <o:p></o:p></span></b></p></td><td valign=top style='border-top:solid #4F81BD 1.0pt;border-left:none;border-bottom:solid #4F81BD 1.0pt;border-right:none;background:#4F81BD;padding:0in 5.4pt 0in 5.4pt;height:5.75pt'><p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:11.0pt;color:white'>Description <o:p></o:p></span></b></p></td><td valign=top style='border-top:solid #4F81BD 1.0pt;border-left:none;border-bottom:solid #4F81BD 1.0pt;border-right:none;background:#4F81BD;padding:0in 5.4pt 0in 5.4pt;height:5.75pt'><p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:11.0pt;color:white'>Configurable Item<o:p></o:p></span></b></p></td><td valign=top style='border-top:solid #4F81BD 1.0pt;border-left:none;border-bottom:solid #4F81BD 1.0pt;border-right:none;background:#4F81BD;padding:0in 5.4pt 0in 5.4pt;height:5.75pt'><p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:11.0pt;color:white'>Severity<o:p></o:p></span></b></p></td><td valign=top style='border-top:solid #4F81BD 1.0pt;border-left:none;border-bottom:solid #4F81BD 1.0pt;border-right:none;background:#4F81BD;padding:0in 5.4pt 0in 5.4pt;height:5.75pt'><p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:11.0pt;color:white'>Open Time<o:p></o:p></span></b></p></td></tr>");
		 //Adding Rows by iterating List
		taskDetails.forEach(data -> {
			content.append(
					"<tr><td valign=top style='border:solid #95B3D7 1.0pt;border-top:none;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><a href=\"http://rri1asmpw1v.corp.cvscaremark.com/asmzone/task/TaskEntryPP.asp?TaskID="
							+ data.getTdt_task_id() + "\"><span style='font-size:11.0pt'>" + data.getTdt_task_id()
							+ "</span></a><b><span style='font-size:11.0pt'><o:p></o:p></span></b></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>"
							+ checkModule(data.getTdt_appln_id())
							+ "<o:p></o:p></span></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>"
							+ data.getTdt_pblm_desc()
							+ "<o:p></o:p></span></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>"
							+ data.getTdt_configurable_item()
							+ "<o:p></o:p></span></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>"
							+ data.getTdt_task_svrty_2()
							+ "<o:p></o:p></span></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>"
							+ data.getTdt_event_notif_dt() + "<o:p></o:p></span></p></td></tr>");
		});
		 
		//Adding Footer
		
		content.append("</table><p class=MsoNormal><br><b><span style='font-family:\"Calibri\",sans-serif'>Go to <a href=\""+ossDashboardLink+"\">OSS Dashboard</a> to update status.<o:p></o:p></span></b></p><p class=MsoNormal style='margin-bottom:12.0pt'><b><o:p>&nbsp;</o:p></b></p><div class=MsoNormal align=center style='text-align:center'><b><hr size=2 width=\"100%\" align=center></b></div><p class=MsoNormal><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'><o:p>&nbsp;</o:p></span></p><p class=MsoNormal style='line-height:12.0pt;mso-line-height-rule:exactly;text-autospace:none'><b><span style='font-size:10.0pt;font-family:\"Century Gothic\",sans-serif;color:#548DD4'>OSS Dashboard </span></b><span style='font-size:8.0pt;font-family:\"Verdana\",sans-serif;color:#595959'>�</span><span style='font-size:9.0pt;font-family:\"Franklin Gothic Book\",sans-serif;color:red'>| OSS Production Support</span><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:red'><o:p></o:p></span></p><p class=MsoNormal><b><span style='font-size:9.0pt;font-family:\"Franklin Gothic Book\",sans-serif;color:#595959'>p</span></b><span style='font-size:9.0pt;font-family:\"Franklin Gothic Book\",sans-serif;color:#595959'> 4017701700 <o:p></o:p></span></p><p class=MsoNormal style='line-height:12.0pt;mso-line-height-rule:exactly;text-autospace:none'><b><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:red'>CVS Health</span></b><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:black'> </span><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'><o:p></o:p></span></p><p class=MsoNormal><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'><o:p>&nbsp;</o:p></span></p><h4><o:p>&nbsp;</o:p></h4></div></body></html>");
		 
		return content.toString();
	}
	private static String checkModule(Integer appID) {
		String module=null;
		switch(appID){
		case 640:
			module="DW";
			break;
		case 663:
			module="eCVS";
			break;
		case 372:
			module="eCVS";
			break;
		case 11:
			module="MF";
			break;
		case 620:
			module="RXC BATCH TEAM";
			break;
		case 628:
			module="RXC App Team";
			break;
		default:
			module="eCVS";
			break;
		}
		return module;
	}
	
	public static boolean sendErrorNotification(Exception e) throws IOException{  
		 logger.info("Called sendErrorNotification() method to send Errors through email.");
		 prop.load(input);
		 logger.info("Setting up environment.");
		 	ossDashboardLink = prop.getProperty("mail.sendMail.ossDashboardLink");
			sendEmailHost = prop.getProperty("mail.sendMail.smtp.host");
			sendEmailFrom = prop.getProperty("mail.sendEmail.from");
			sendEmailTo = prop.getProperty("mail.sendEmail.to");
			sendEmailCc = prop.getProperty("mail.sendMail.cc");
			
		 String timeStamp = new SimpleDateFormat("MMM dd yyyy HH:mm").format(Calendar.getInstance().getTime());
		 logger.info("Generating Email message.");
		 String sub="OSSIncidentAutomation Error report, Exception occured : "+timeStamp;
		 logger.info("Subject of Email :"+sub);
		 logger.info("Creating Contents of Email body.");
		 String msg=createErrorContent(e);
        Properties props = new Properties();
        props.put("mail.smtp.host", sendEmailHost);
        props.put("mail.smtp.starttls.enable", "true");
        logger.info("Host :"+sendEmailHost);
        //get Session   
        Session session = Session.getInstance(props,    
         new javax.mail.Authenticator() {    
         protected PasswordAuthentication getPasswordAuthentication() {    
         return new PasswordAuthentication(sendEmailFrom ,"");  
         }    
        });    
        //compose message    
        try {    
       	 StringTokenizer strTok = new StringTokenizer(sendEmailTo, ";");
   	     int iEmailIdCount = 0;
   	     String[] emailIds = new String[strTok.countTokens()];
   	     while (strTok.hasMoreTokens())
   	     {
   	       emailIds[iEmailIdCount] = strTok.nextToken();
   	       iEmailIdCount++;
   	     }
   	     StringTokenizer strTokcc = new StringTokenizer(sendEmailCc, ";");
   	     int iccEmailIdCount = 0;
   	     String[] emailIdscc = new String[strTokcc.countTokens()];
   	     while (strTokcc.hasMoreTokens())
   	     {
   	       emailIdscc[iccEmailIdCount] = strTokcc.nextToken();
   	       iccEmailIdCount++;
   	     }
       	 InternetAddress[] addressTo = new InternetAddress[emailIds.length];
            for (int i = 0; i < emailIds.length; i++)
            {
              addressTo[i] = new InternetAddress(emailIds[i]);
            }
            InternetAddress[] addressCc = new InternetAddress[emailIdscc.length];
            for (int i = 0; i < emailIdscc.length; i++)
            {
              addressCc[i] = new InternetAddress(emailIdscc[i]);
            }
         MimeMessage message = new MimeMessage(session);    
         message.setRecipients(Message.RecipientType.CC,addressCc);
//         message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
         message.setRecipients(Message.RecipientType.TO, addressTo);
         message.setSubject(sub);    
         message.setFrom(new InternetAddress(sendEmailFrom));
         message.setText(msg);  
         message.setContent(msg, "text/html; charset=utf-8");
         //send message  
         logger.info("Sending Email..");
         Transport.send(message);    
         logger.info("Email sent successfully.");


         return true;
         
        } catch (MessagingException m) {throw new RuntimeException(m); }    
           
  }
	private static String createErrorContent(Exception e) {
		 StringBuffer content=new StringBuffer();
		 //Adding Header
		content.append(
				"<html xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\" xmlns=\"http://www.w3.org/TR/REC-html40\"><head><meta http-equiv=Content-Type content=\"text/html; charset=utf-8\"><meta name=Generator content=\"Microsoft Word 15 (filtered medium)\"><!--[if !mso]><style>v/:* {behavior:url(#default#VML);}"
						+ "o\"+':'+" + "* {behavior:url(#default#VML);}w\"+':'+"
						+ "* {behavior:url(#default#VML);}.shape {behavior:url(#default#VML);}</style><![endif]--><style><!--/* Font Definitions */@font-face{font-family:\"Cambria Math\";panose-1:2 4 5 3 5 4 6 3 2 4;}@font-face	{font-family:Calibri;	panose-1:2 15 5 2 2 2 4 3 2 4;}@font-face	{font-family:Verdana;	panose-1:2 11 6 4 3 5 4 4 2 4;}@font-face	{font-family:Cambria;	panose-1:2 4 5 3 5 4 6 3 2 4;}@font-face	{font-family:\"Century Gothic\";	panose-1:2 11 5 2 2 2 2 2 2 4;}@font-face	{font-family:\"Franklin Gothic Book\";	panose-1:2 11 5 3 2 1 2 2 2 4;}* Style Definitions */p.MsoNormal, li.MsoNormal, div.MsoNormal	{margin:0in;	margin-bottom:.0001pt;	font-size:12.0pt;	font-family:\"Times New Roman\",serif;}"
						+ "h4	{mso-style-priority:9;	mso-style-link:\"Heading 4 Char\";	mso-margin-top-alt:auto;	margin-right:0in;	mso-margin-bottom-alt:auto;	margin-left:0in;	font-size:12.0pt;	font-family:\"Times New Roman\",serif;	font-weight:bold;}a:link, span.MsoHyperlink	{mso-style-priority:99;	color:blue;	text-decoration:underline;}a:visited, span.MsoHyperlinkFollowed	{mso-style-priority:99;	color:purple;	text-decoration:underline;}p	{mso-style-priority:99;	mso-margin-top-alt:auto;	margin-right:0in;	mso-margin-bottom-alt:auto;	margin-left:0in;	font-size:12.0pt;	font-family:\"Times New Roman\",serif;}span.Heading4Char	{mso-style-name:\"Heading 4 Char\";	mso-style-priority:9;	mso-style-link:\"Heading 4\";font-family:\"Cambria\",serif;color:#365F91;	font-style:italic;}span.EmailStyle19"
						+ "	{mso-style-type:personal;	font-family:\"Calibri\",sans-serif;	color:windowtext;	font-weight:normal;	font-style:normal;	text-decoration:none none;}span.EmailStyle20	{mso-style-type:personal;	font-family:\"Calibri\",sans-serif;	color:windowtext;font-weight:normal;	font-style:normal;	text-decoration:none none;}span.EmailStyle21	{mso-style-type:personal-reply;	font-family:\"Calibri\",sans-serif;	color:#1F497D;}.MsoChpDefault	{mso-style-type:export-only;	font-size:10.0pt;}@page WordSection1	{size:8.5in 11.0in;	margin:1.0in 1.0in 1.0in 1.0in;}div.WordSection1	{page:WordSection1;}--></style><!--[if gte mso 9]><xml><o:shapedefaults v:ext=\"edit\" spidmax=\"1026\" /></xml><![endif]--><!--[if gte mso 9]><xml><o:shapelayout v:ext=\"edit\"><o:idmap v:ext=\"edit\" data=\"1\" /></o:shapelayout></xml><![endif]--></head><body lang=EN-US link=blue vlink=purple><div class=WordSection1><p class=MsoNormal><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'>Hi Team, <br><br>Following Exception/Error has been occured, please have a look and do the needful.<o:p></o:p></span></p><p class=MsoNormal><o:p>&nbsp;</o:p></p>");
		//Adding Exception Message
		content.append("There was a problem due to : "+e.getMessage()+"<p class=MsoNormal><o:p>Below is the complete stack trace:&nbsp;</o:p></p>");
		List<StackTraceElement> Errors=Arrays.asList(e.getStackTrace());
		Errors.forEach(error-> {
			content.append(error.toString());
			content.append("<br>");
		});
		//Adding Footer
		content.append("<p class=MsoNormal style='margin-bottom:12.0pt'><b><o:p>&nbsp;</o:p></b></p><div class=MsoNormal align=center style='text-align:center'><b><hr size=2 width=\"100%\" align=center></b></div><p class=MsoNormal><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'><o:p>&nbsp;</o:p></span></p><p class=MsoNormal style='line-height:12.0pt;mso-line-height-rule:exactly;text-autospace:none'><b><span style='font-size:10.0pt;font-family:\"Century Gothic\",sans-serif;color:#548DD4'>OSS Dashboard </span></b><span style='font-size:8.0pt;font-family:\"Verdana\",sans-serif;color:#595959'>�</span><span style='font-size:9.0pt;font-family:\"Franklin Gothic Book\",sans-serif;color:red'>| OSS Production Support</span><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:red'><o:p></o:p></span></p><p class=MsoNormal><b><span style='font-size:9.0pt;font-family:\"Franklin Gothic Book\",sans-serif;color:#595959'>p</span></b><span style='font-size:9.0pt;font-family:\"Franklin Gothic Book\",sans-serif;color:#595959'> 4017701700 <o:p></o:p></span></p><p class=MsoNormal style='line-height:12.0pt;mso-line-height-rule:exactly;text-autospace:none'><b><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:red'>CVS Health</span></b><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:black'> </span><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'><o:p></o:p></span></p><p class=MsoNormal><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'><o:p>&nbsp;</o:p></span></p><h4><o:p>&nbsp;</o:p></h4></div></body></html>");
		 
		return content.toString();
	}
	
	public static void main(String[] args) {
		
		System.out.println("Sending Email");
		try {
//			String content = "<html xmlns:v='urn:schemas-microsoft-com:vml' xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns:m='http://schemas.microsoft.com/office/2004/12/omml' xmlns='http://www.w3.org/TR/REC-html40'><head><meta http-equiv=Content-Type content='text/html; charset=utf-8'><meta name=Generator content='Microsoft Word 15 (filtered medium)'><style><!--"
//					+ "@font-face	{font-family:'Cambria Math';	pan'se-1:2 4 5 3 5 4 6 3 2 4;}@font-face	{font-family:Calibri;	panose-1:2 15 5 2 2 2 4 3 2 4;}@font-face	{font-family:'Century Gothic';	panose-1:2 11 5 2 2 2 2 2 2 4;}@font-face	{font-family:'Franklin Gothic Book';	panose-1:2 11 5 3 2 1 2 2 2 4;}/* Style Definitions */p.MsoNormal, li.MsoNormal, div.MsoNormal	{margin:0in;	margin-bottom:.0001pt;	font-size:12.0pt;	font-family:'Times New Roman',serif;}a:link, span.MsoHyperlink	{mso-style-priority:99;	color:#0563C1;	text-decoration:underline;}a:visited, span.MsoHyperlinkFollowed	{mso-style-priority:99;	color:#954F72;	text-decoration:underline;}span.EmailStyle17	{mso-style-type:personal-reply;	font-family:'Calibri',sans-serif;	color:#1F497D;}.MsoChpDefault	{mso-style-type:export-only;	font-family:'Calibri',sans-serif;}@page WordSection1	{size:8.5in 11.0in;	margin:1.0in 1.0in 1.0in 1.0in;}div.WordSection1	{page:WordSection1;}--></style><!--[if gte mso 9]><xml><o:shapedefaults v:ext='edit' spidmax='1026' /></xml><![endif]--><!--[if gte mso 9]><xml><o:shapelayout v:ext='edit'><o:idmap v:ext='edit' data='1' /></o:shapelayout></xml><![endif]--></head><body lang=EN-US link='#0563C1' vlink='#954F72'><div class=WordSection1><p class=MsoNormal><span style='font-size:11.0pt;font-family:'Calibri',sans-serif;color:#1F497D'>Hey Aman/Abhishek, <o:p></o:p></span></p><p class=MsoNormal><span style='font-size:11.0pt;font-family:'Calibri',sans-serif;color:#1F497D'><o:p>&nbsp;</o:p></span></p><p class=MsoNormal><span style='font-size:11.0pt;font-family:'Calibri',sans-serif;color:#1F497D'>You guys are a piece of work. I always aspire your talent and dedication to provide values to this project. <o:p></o:p></span></p><p class=MsoNormal><span style='font-size:11.0pt;font-family:'Calibri',sans-serif;color:#1F497D'><o:p>&nbsp;</o:p></span></p><p class=MsoNormal><span style='font-size:11.0pt;font-family:'Calibri',sans-serif;color:#1F497D'>KEEP UP THE GOOD WORK AND SHOCK THE MANAGEMENT WITH YOUR GOOD WORK! :)<o:p></o:p></span></p><p class=MsoNormal><span style='font-size:11.0pt;font-family:'Calibri',sans-serif;color:#1F497D'><o:p>&nbsp;</o:p></span></p><p class=MsoNormal><b><span style='font-size:10.0pt;color:#1F497D'>Regards,<o:p></o:p></span></b></p><p class=MsoNormal style='line-height:12.0pt;mso-line-height-rule:exactly'><b><span style='font-size:10.0pt;color:black'>Abhinav Sharma</span></b><span style='color:black'>| </span><b><span style='font-size:9.0pt;font-family:\"Century Gothic\",sans-serif;color:red'>OSS Production Support Offshore � Core Batch</span></b><span style='font-size:11.0pt;color:red'><o:p></o:p></span></p><p class=MsoNormal style='line-height:12.0pt;mso-line-height-rule:exactly'><span style='font-size:10.0pt;color:black'>p </span><span style='font-size:9.0pt;font-family:'Franklin Gothic Book',sans-serif;color:#1F497D'>401-770-3400</span><span style='font-size:10.0pt;color:black'><o:p></o:p></span></p><p class=MsoNormal style='line-height:12.0pt;mso-line-height-rule:exactly'><b><span style='font-size:10.0pt;color:red'>CVS Health</span></b><span style='color:black'> | </span><span style='font-size:10.0pt;color:black'>Skyview Corporate Park, Sec-74-A, Gurgaon, India<o:p></o:p></span></p><p class=MsoNormal style='line-height:12.0pt;mso-line-height-rule:exactly'><span style='font-size:11.0pt;color:#1F497D'><o:p>&nbsp;</o:p></span></p><p class=MsoNormal><span style='font-size:11.0pt;font-family:'Calibri',sans-serif;color:#1F497D'><o:p>&nbsp;</o:p></span></p><p class=MsoNormal><b> </b><o:p></o:p></p></div></body></html>";
			String content="<html xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\" xmlns=\"http://www.w3.org/TR/REC-html40\"><head><meta http-equiv=Content-Type content=\"text/html; charset=utf-8\"><meta name=Generator content=\"Microsoft Word 15 (filtered medium)\"><!--[if !mso]><style>v/:* {behavior:url(#default#VML);}"
					+"o\"+':'+"+"* {behavior:url(#default#VML);}w\"+':'+"+"* {behavior:url(#default#VML);}.shape {behavior:url(#default#VML);}</style><![endif]--><style><!--/* Font Definitions */@font-face{font-family:\"Cambria Math\";panose-1:2 4 5 3 5 4 6 3 2 4;}@font-face	{font-family:Calibri;	panose-1:2 15 5 2 2 2 4 3 2 4;}@font-face	{font-family:Verdana;	panose-1:2 11 6 4 3 5 4 4 2 4;}@font-face	{font-family:Cambria;	panose-1:2 4 5 3 5 4 6 3 2 4;}@font-face	{font-family:\"Century Gothic\";	panose-1:2 11 5 2 2 2 2 2 2 4;}@font-face	{font-family:\"Franklin Gothic Book\";	panose-1:2 11 5 3 2 1 2 2 2 4;}* Style Definitions */p.MsoNormal, li.MsoNormal, div.MsoNormal	{margin:0in;	margin-bottom:.0001pt;	font-size:12.0pt;	font-family:\"Times New Roman\",serif;}"
					+"h4	{mso-style-priority:9;	mso-style-link:\"Heading 4 Char\";	mso-margin-top-alt:auto;	margin-right:0in;	mso-margin-bottom-alt:auto;	margin-left:0in;	font-size:12.0pt;	font-family:\"Times New Roman\",serif;	font-weight:bold;}a:link, span.MsoHyperlink	{mso-style-priority:99;	color:blue;	text-decoration:underline;}a:visited, span.MsoHyperlinkFollowed	{mso-style-priority:99;	color:purple;	text-decoration:underline;}p	{mso-style-priority:99;	mso-margin-top-alt:auto;	margin-right:0in;	mso-margin-bottom-alt:auto;	margin-left:0in;	font-size:12.0pt;	font-family:\"Times New Roman\",serif;}span.Heading4Char	{mso-style-name:\"Heading 4 Char\";	mso-style-priority:9;	mso-style-link:\"Heading 4\";font-family:\"Cambria\",serif;color:#365F91;	font-style:italic;}span.EmailStyle19"
					+"	{mso-style-type:personal;	font-family:\"Calibri\",sans-serif;	color:windowtext;	font-weight:normal;	font-style:normal;	text-decoration:none none;}span.EmailStyle20	{mso-style-type:personal;	font-family:\"Calibri\",sans-serif;	color:windowtext;font-weight:normal;	font-style:normal;	text-decoration:none none;}span.EmailStyle21	{mso-style-type:personal-reply;	font-family:\"Calibri\",sans-serif;	color:#1F497D;}.MsoChpDefault	{mso-style-type:export-only;	font-size:10.0pt;}@page WordSection1	{size:8.5in 11.0in;	margin:1.0in 1.0in 1.0in 1.0in;}div.WordSection1	{page:WordSection1;}--></style><!--[if gte mso 9]><xml><o:shapedefaults v:ext=\"edit\" spidmax=\"1026\" /></xml><![endif]--><!--[if gte mso 9]><xml><o:shapelayout v:ext=\"edit\"><o:idmap v:ext=\"edit\" data=\"1\" /></o:shapelayout></xml><![endif]--></head><body lang=EN-US link=blue vlink=purple><div class=WordSection1><p class=MsoNormal><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'>Hi Team, <br><br>Following alert(s) have been processed.<o:p></o:p></span></p><p class=MsoNormal><o:p>&nbsp;</o:p></p><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style='border-collapse:collapse'><tr style='height:5.75pt'><td valign=top style='border:solid #4F81BD 1.0pt;border-right:none;background:#4F81BD;padding:0in 5.4pt 0in 5.4pt;height:5.75pt'><p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:11.0pt;color:white'>ASM ID<o:p></o:p></span></b></p></td><td valign=top style='border-top:solid #4F81BD 1.0pt;border-left:none;border-bottom:solid #4F81BD 1.0pt;border-right:none;background:#4F81BD;padding:0in 5.4pt 0in 5.4pt;height:5.75pt'><p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:11.0pt;color:white'>Description <o:p></o:p></span></b></p></td><td valign=top style='border-top:solid #4F81BD 1.0pt;border-left:none;border-bottom:solid #4F81BD 1.0pt;border-right:none;background:#4F81BD;padding:0in 5.4pt 0in 5.4pt;height:5.75pt'><p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:11.0pt;color:white'>Configurable Item<o:p></o:p></span></b></p></td><td valign=top style='border-top:solid #4F81BD 1.0pt;border-left:none;border-bottom:solid #4F81BD 1.0pt;border-right:none;background:#4F81BD;padding:0in 5.4pt 0in 5.4pt;height:5.75pt'><p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:11.0pt;color:white'>Severity<o:p></o:p></span></b></p></td><td valign=top style='border-top:solid #4F81BD 1.0pt;border-left:none;border-bottom:solid #4F81BD 1.0pt;border-right:none;background:#4F81BD;padding:0in 5.4pt 0in 5.4pt;height:5.75pt'><p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:11.0pt;color:white'>Open Time<o:p></o:p></span></b></p></td></tr>"
					+"<tr><td valign=top style='border:solid #95B3D7 1.0pt;border-top:none;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><a href=\"http://rri1asmpw1v.corp.cvscaremark.com/asmzone/task/TaskEntryPP.asp?TaskID=204109\"><span style='font-size:11.0pt'>204109</span></a><b><span style='font-size:11.0pt'><o:p></o:p></span></b></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>eCVS<o:p></o:p></span></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>mixd068d_late.sh<o:p></o:p></span></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>Critical<o:p></o:p></span></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>2018-11-15 11:24:43<o:p></o:p></span></p></td></tr>"
					+"<tr><td valign=top style='border:solid #95B3D7 1.0pt;border-top:none;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><a href=\"http://rri1asmpw1v.corp.cvscaremark.com/asmzone/task/TaskEntryPP.asp?TaskID=204077\"><span style='font-size:11.0pt'>204077</span></a><b><span style='font-size:11.0pt'><o:p></o:p></span></b></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>eCVS<o:p></o:p></span></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>rri1rxiapa4<o:p></o:p></span></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>Critical<o:p></o:p></span></p></td><td valign=top style='border-top:none;border-left:none;border-bottom:solid #95B3D7 1.0pt;border-right:solid #95B3D7 1.0pt;background:#DBE5F1;padding:0in 5.4pt 0in 5.4pt'><p class=MsoNormal align=center style='text-align:center'><span style='font-size:11.0pt'>2018-11-15 10:13:01<o:p></o:p></span></p></td></tr>"
					+ "</table><p class=MsoNormal><br><b><span style='font-family:\"Calibri\",sans-serif'>Go to <a href=\"http://10.31.65.140:8080/OSSApp/#!/OSSDashboard\">OSS Dashboard</a> to update status.<o:p></o:p></span></b></p><p class=MsoNormal style='margin-bottom:12.0pt'><b><o:p>&nbsp;</o:p></b></p><div class=MsoNormal align=center style='text-align:center'><b><hr size=2 width=\"100%\" align=center></b></div><p class=MsoNormal><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'><o:p>&nbsp;</o:p></span></p><p class=MsoNormal style='line-height:12.0pt;mso-line-height-rule:exactly;text-autospace:none'><b><span style='font-size:10.0pt;font-family:\"Century Gothic\",sans-serif;color:#548DD4'>OSS Dashboard </span></b><span style='font-size:8.0pt;font-family:\"Verdana\",sans-serif;color:#595959'>�</span><span style='font-size:9.0pt;font-family:\"Franklin Gothic Book\",sans-serif;color:red'>| OSS Production Support</span><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:red'><o:p></o:p></span></p><p class=MsoNormal><b><span style='font-size:9.0pt;font-family:\"Franklin Gothic Book\",sans-serif;color:#595959'>p</span></b><span style='font-size:9.0pt;font-family:\"Franklin Gothic Book\",sans-serif;color:#595959'> 4017701700 <o:p></o:p></span></p><p class=MsoNormal style='line-height:12.0pt;mso-line-height-rule:exactly;text-autospace:none'><b><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:red'>CVS Health</span></b><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:black'> </span><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'><o:p></o:p></span></p><p class=MsoNormal><span style='font-size:11.0pt;font-family:\"Calibri\",sans-serif;color:#1F497D'><o:p>&nbsp;</o:p></span></p><h4><o:p>&nbsp;</o:p></h4></div></body></html>";
			send("paz1trendvip", "Abhinav.Sharma@CVSHealth.com", "Welcome1", "abhishek.saxena2@cvscaremark.com", "", "Testing", content);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
