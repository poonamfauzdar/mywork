package com.oss.mail.db.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.oss.mail.util.EncryptedDataSource;

@Configuration
@ComponentScan(basePackages = "")
@PropertySource(value = { "classpath:app.properties" })
public class ASMBeanConfig {

	@Autowired
	private Environment env;

	@Bean
	public EncryptedDataSource dataSource() {

		EncryptedDataSource dataSource = new EncryptedDataSource();
		dataSource.setDriverClassName(env.getRequiredProperty("jdbc.driverClassName"));
		dataSource.setUrl(env.getRequiredProperty("jdbc.databaseurl"));
		dataSource.setUsername(env.getRequiredProperty("jdbc.username"));
		dataSource.setPassword(env.getRequiredProperty("jdbc.password"));

		return dataSource;

	}

}
