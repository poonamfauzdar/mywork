package com.oss.mail.db.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.oss.mail.util.EncryptedDataSource;

@Configuration
@ComponentScan(basePackages = "")
@PropertySource(value = { "classpath:application.properties" })
public class HPSMBeanConfig {

	@Autowired
	private Environment env;

	@Bean
	public EncryptedDataSource dataSource() {

		EncryptedDataSource dataSource = new EncryptedDataSource();
		dataSource.setDriverClassName(env.getRequiredProperty("hpsm.jdbc.driverClassName"));
		dataSource.setUrl(env.getRequiredProperty("hpsm.jdbc.url"));
		dataSource.setUsername(env.getRequiredProperty("hpsm.jdbc.username"));
		dataSource.setPassword(env.getRequiredProperty("hpsm.jdbc.password"));

		return dataSource;
	}
}
