package com.oss.mail.dao;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.oss.mail.beans.TaskDetails;
import com.oss.mail.util.SendEmail;

@Repository
public class TaskDetailsDaoImpl implements TaskDetailsDao {

	static Logger logger = LogManager.getLogger(TaskDetailsDaoImpl.class.getName());
	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		logger.info("Setting up Session Factory");
		this.sessionFactory = sessionFactory;
	}

	@Override
	public TaskDetails addTaskDetails(TaskDetails taskDetails) {
		logger.info("called addTaskDetails()");
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			int result = (Integer) session.save(taskDetails);
			taskDetails.setTdt_task_id(result);
			session.getTransaction().commit();
			session.close();
		} catch (Exception e) {
			session.close();
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return taskDetails;
	}

	@Override
	public TaskDetails updateTaskDetails(TaskDetails taskDetails) {
		logger.info("called updatetaskDetails()");
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			session.update(taskDetails);
			session.getTransaction().commit();
			session.close();
		} catch (Exception e) {
			session.close();
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return taskDetails;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<TaskDetails> listTaskDetails() {
		logger.info("called listTaskDetails()");
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			List<TaskDetails> list = session.createQuery("from TaskDetails").list();
			session.close();
			return list;
		} catch (Exception e) {
			session.close();
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public TaskDetails getTaskDetailsById(Integer tdt_task_id) {
		logger.info("called getTaskDetailsById() for tdt_task_id : " + tdt_task_id);
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			List<TaskDetails> list = session.createQuery("from TaskDetails t where t.id = :tdt_task_Id")
					.setParameter("tdt_task_Id", tdt_task_id).list();
			session.close();
			return list.size() > 0 ? (TaskDetails) list.get(0) : null;
		} catch (Exception e) {
			session.close();
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return null;
	}

	@Override
	public void removeTaskDetails(Integer tdt_task_id) {
		logger.info("called removetaskDetails() for tdt_task_id : " + tdt_task_id);
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			TaskDetails tdt = (TaskDetails) session.load(TaskDetails.class, tdt_task_id);
			if (null != tdt) {
				session.delete(tdt);
			}
			session.getTransaction().commit();
			session.close();
		} catch (Exception e) {
			session.close();
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
	}

}
