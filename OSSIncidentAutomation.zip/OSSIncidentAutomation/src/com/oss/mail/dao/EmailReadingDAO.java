package com.oss.mail.dao;

import java.util.List;
import java.util.Map;

import com.oss.mail.beans.TaskDetails;

public interface EmailReadingDAO {

	public List<TaskDetails> readEmailDao();

	public List<TaskDetails> processEmails(Map<String, String> emails);

	public void processTaskDetailsTable(String notif_date, String reciepient, String alert);

	public void processTaskEventDetailsTable(List<TaskDetails> taskDetails);
}
