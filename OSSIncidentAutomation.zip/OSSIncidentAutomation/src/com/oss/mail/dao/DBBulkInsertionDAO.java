package com.oss.mail.dao;

import java.util.List;

import com.oss.mail.beans.TaskDetails;
import com.oss.mail.beans.TaskEventDetails;

public interface DBBulkInsertionDAO {

	public List<TaskDetails> insertBulkData(List<TaskDetails> taskDetailsList, List<TaskEventDetails> taskEventDetails);
}
