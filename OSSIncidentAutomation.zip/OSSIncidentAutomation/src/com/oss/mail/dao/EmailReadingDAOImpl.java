package com.oss.mail.dao;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.oss.mail.beans.TaskDetails;
import com.oss.mail.beans.TaskEventDetails;
import com.oss.mail.util.GetEmails;
import com.oss.mail.util.SecurityUtil;
import com.oss.mail.util.SendEmail;
import com.oss.mail.dao.EmailReadingDAO;

@Repository
public class EmailReadingDAOImpl implements EmailReadingDAO {
	static Logger logger = LogManager.getLogger(EmailReadingDAOImpl.class.getName());

	@Autowired
	DBBulkInsertionDAO dbBulkInsertionDAO;

	GetEmails getEmailsUtil = new GetEmails();

	String emailHost;
	String emailPort;
	String emailUserName;
	String emailPassword;
	String emailSender;
	String inputFolder;
	String backupFolder;
	String exclusionListFile;
	String exclusionFolder;
	String splitter;
	int NoOfEmails;

	String ossDashboardLink;
	String sendEmailHost;
	String sendEmailFrom;
	String sendEmailTo;
	String sendEmailCc;

	Properties prop = new Properties();
	ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
	InputStream input = classLoader.getResourceAsStream("app.properties");

	List<TaskDetails> taskDetailsList = new ArrayList<TaskDetails>();
	List<TaskEventDetails> taskEventDetailsList = new ArrayList<TaskEventDetails>();
	List<TaskDetails> result = new ArrayList<TaskDetails>();
	List<String> exclusionList = new ArrayList<String>();

	static boolean flag = true;

	SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
	String sysdate = dateFormat.format(new Date());

	private Stream<String> stream;

	public List<TaskDetails> readEmailDao() {
		try {
			prop.load(input);
			logger.info("Called readEmailDao() from EmailReadingDAOService");
			Map<String, String> emailsMap = new HashMap<String, String>();

			exclusionListFile = prop.getProperty("mail.exclustionListFilePath");
			emailHost = prop.getProperty("mail.imap.host");
			emailPort = prop.getProperty("mail.imap.port");
			emailUserName = prop.getProperty("mail.imap.username");
			emailPassword = SecurityUtil.decrypt(prop.getProperty("mail.imap.password"));
			emailSender = prop.getProperty("mail.imap.sender");
			inputFolder = prop.getProperty("mail.imap.inputFolder");
			backupFolder = prop.getProperty("mail.imap.backupFolder");
			NoOfEmails = Integer.parseInt(prop.getProperty("mail.NoOfEmails"));
			exclusionListFile = prop.getProperty("mail.exclustionListFilePath");
			exclusionFolder = prop.getProperty("mail.imap.exclusionFolder");
			splitter=prop.getProperty("mail.string.Splitter");

			ossDashboardLink = prop.getProperty("mail.sendMail.ossDashboardLink");
			sendEmailHost = prop.getProperty("mail.sendMail.smtp.host");
			sendEmailFrom = prop.getProperty("mail.sendEmail.from");
			sendEmailTo = prop.getProperty("mail.sendEmail.to");
			sendEmailCc = prop.getProperty("mail.sendMail.cc");

			logger.info("Setting up the Email Environment");
			logger.info("Host : " + emailHost + ",Port : " + emailPort + ",Username : " + emailUserName);

			if (!emailsMap.isEmpty()) {
				logger.info("Clearing emails map.");
				emailsMap.clear();
			}
			logger.info("Calling getEmails() from DAO");
			stream = Files.lines(Paths.get(exclusionListFile), Charset.forName("Cp1252"));
			exclusionList.clear();
			stream.forEach(alert -> {
				exclusionList.add(alert);
			});
			getEmailsUtil.getEmails(emailHost, emailPort, emailUserName, emailPassword, NoOfEmails, inputFolder, splitter)
					.entrySet().stream().filter(e -> {
						logger.info("Filtering message from exclusion list :" + e);
						// if (!exclusionList.isEmpty()) {
						// if (exclusionList.contains(e.getKey())) {
						// flag = false;
						// logger.info(
						// "Email Exists in Exclusion List, setting up returning
						// flag to false :" + flag);
						// } else {
						// flag = true;
						// logger.info(
						// "Email Doesn't Exists in Exclusion List, setting up
						// returning flag to true :"
						// + flag);
						// }
						// } else if (exclusionList.isEmpty()) {
						// flag = true;
						// logger.info("Exclusion List was empty, setting Return
						// Flag to true : " + flag);
						// }
						if (!exclusionList.isEmpty()) {
							for (String excl : exclusionList) {
								if (e.getKey().contains(excl)) {
									flag = false;
									logger.info("Email Exists in Exclusion List, setting up returning flag to false :"
											+ flag);
									break;
								} else {
									flag = true;
									logger.info(
											"Email Doesn't Exists in Exclusion List, setting up returning flag to true :"
													+ flag);
								}
							}
						} else if (exclusionList.isEmpty()) {
							flag = true;
							logger.info("Exclusion List was empty, setting Return Flag to true : " + flag);
						}
						logger.info("Return Flag :" + flag);
						return flag;
					}).forEach(data -> emailsMap.put(data.getKey(), data.getValue()));

			logger.info("Size of Email Map: " + emailsMap.size());
			if (emailsMap.size() > 0) {
				logger.info("Email(s) have been read successfully. Processing Emails now by calling processEmail().");
				logger.info("Calling processEmails() for " + emailsMap.size() + " emails");
				return processEmails(emailsMap);
			} else {
				logger.info("There was no emails in Email Map to process.");
			}
			return null;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return null;
	}

	public List<TaskDetails> processEmails(Map<String, String> emails) {
		logger.info("Clear contents of existing data in lists.");
		try {
			result.clear();
			taskDetailsList.clear();
			taskEventDetailsList.clear();
			logger.info("Called processEmail() from EmailReadingDao for " + emails.size() + " E-Mails.");
			logger.info("Iterating through Java Stream API");
			logger.info("Processing start for TaskDetails table, streaming the emails map.");
			emails.entrySet().stream().forEach(e -> {
				System.out.println("MAP Entry: " + e.getKey() + ":" + e.getValue());
				String data[] = e.getValue().split(splitter);

				logger.info("Calling processTaskDetailsTable() method to populate taskDetailsList.");
				processTaskDetailsTable(data[0], data[1], data[2]);
				logger.info("Task Details List Size :" + taskDetailsList.size());
			});
			logger.info("Processing start for TaskEventDetails table, streaming the emails taskDetailsList.");
			logger.info(
					"Calling processTaskEventDetailsTable() method to populate taskEventDetailsList with taskDetailsList as parameter.");
			processTaskEventDetailsTable(taskDetailsList);
			logger.info("Task Event Details List Size :" + taskEventDetailsList.size());
			logger.info(
					"Invoking Bulk Insertion by calling insertBulkData() of DBBulkInsertionDAO for two Lists : TaskDetails, TaskEventDetails");
			result = dbBulkInsertionDAO.insertBulkData(taskDetailsList, taskEventDetailsList);

			List<String> Desc = new ArrayList<String>();
			if (!result.isEmpty()) {
				Desc.clear();
				logger.info("Database insertion was successful, " + result.size() + " records inserted.");
				logger.info("Now, we are proceeding with backup the processed emails to " + backupFolder
						+ " and exclusion emails to " + exclusionFolder + " and remove from " + inputFolder
						+ " folder");
				result.stream().forEach(e -> {
					Desc.add(e.getTdt_pblm_desc());
				});
				if (getEmailsUtil.backUpAndRemoveEmails(Desc, emailHost, emailPort, emailUserName, emailPassword,
						inputFolder, backupFolder, exclusionFolder, exclusionList)) {
					logger.info("Processed Emails have been successfully backed up.");
					logger.info("Now, we are sending Email Confirmation to teams");
					try {
						if (SendEmail.sendSuccessNotification(result)) {
							logger.info("Email Confirmation has been successfully sent.");
						}
					} catch (IOException e1) {
						logger.error(e1.getMessage(), e1);
						try {
							SendEmail.sendErrorNotification(e1);
						} catch (IOException e2) {
							logger.error(e1.getMessage(), e2);
						}
					}
					return result;
				}
			}

			return result;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return result;
	}

	public void processTaskDetailsTable(String notif_date, String reciepient, String alert) {
		logger.info("Called processTaskDetailsTable() method to extract fields for TaskDetails table");
		TaskDetails taskDetails = new TaskDetails();
		try {

			// DateTimeFormatter formatter =
			// DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");
			// SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy
			// HH:mm:ss");
			// DateTimeFormatter formatter =
			// DateTimeFormatter.ISO_LOCAL_DATE_TIME;
			// LocalDate dateTime = LocalDate.parse(data[0], formatter);
			// System.out.println(dateTime.format(formatter));
			// Date dateTime=dateFormat.format(data[0]);
			// Date date = Date.valueOf(dateTime);
			// alert.setReceivedDate(data[0]);
			// alert.setFrom(data[1]);
			// alert.setAlertString(data[2]);
			taskDetails.setTdt_tech_id(3);
			String ticketNo = notif_date;
			taskDetails.setTdt_EA_tkt("T_" + (ticketNo.replaceAll("-", "").substring(0, 8)));
			taskDetails.setTdt_pvcs_num("");
			taskDetails.setTdt_task_svrty(-1);
			taskDetails.setTdt_pblm_desc(alert);
			taskDetails.setTdt_resol_status_id(1);
			taskDetails.setTdt_prjtd_effort(0.00);
			taskDetails.setTdt_act_effort(0.00);
			taskDetails.setTdt_pblm_soln("");// tweak this
			taskDetails.setTdt_upd_time(sysdate);
			taskDetails.setTdt_niku_flag("N");
			taskDetails.setTdt_event_notif_dt(notif_date);
			taskDetails.setTdt_ext_sys_id("");
			taskDetails.setTdt_shift(2);
			taskDetails.setTdt_assigned_to("MXMX");
			taskDetails.setTdt_incident_type(0);
			taskDetails.setTdt_change_related("3");
			taskDetails.setTdt_ccb_num("NA");
			taskDetails.setTdt_outage_related("1");
			taskDetails.setTdt_esc_to_cvs("2");
			taskDetails.setTdt_esc_reason("3");
			taskDetails.setTdt_remediation("");
			taskDetails.setTdt_ccb_num_2("");
			taskDetails.setTdt_recovery_sol("");// tweak this
			taskDetails.setTdt_root_cause_no(-1);
			taskDetails.setTdt_engmt_id(4);
			taskDetails.setTdt_recovery_ccb("");
			taskDetails.setTdt_remediation_req("NO");
			taskDetails.setTdt_active("Y");
			taskDetails.setTdt_freeze("N");
			taskDetails.setTdt_high_level_cause(-1);
			taskDetails.setTemplate_flag("");
			taskDetails.setTdt_incidents_count(1);
			taskDetails.setTdt_sen_count(2);
			taskDetails.setTdt_vend_id(-1);
			taskDetails.setTdt_esc_to_onsite_id(2);
			taskDetails.setTdt_reason_esc_onsite_id(4);
			taskDetails.setTdt_unixdba_number("");
			taskDetails.setTdt_defect_id("");
			taskDetails.setNo_Of_Resources("1");
			taskDetails.setFuture_Column1(0);
			// Add after

			/*
			 * IIF(tdt_bus_area_id=31 AND tdt_bus_unit_id=9,88,
			 * IIF(tdt_bus_area_id=51 AND tdt_bus_unit_id=27,620,
			 * IIF(tdt_bus_unit_id= 22 AND tdt_bus_area_id=50,372,
			 * IIF(tdt_bus_unit_id=6 AND tdt_bus_area_id=7,563,
			 * IIF(tdt_bus_unit_id=31 AND tdt_bus_area_id=58,551,
			 * IIF(tdt_bus_unit_id=32 AND tdt_bus_area_id=59,525,
			 * IIF(tdt_bus_unit_id=54 AND tdt_bus_area_id=88,628,
			 * IIF(tdt_bus_unit_id=42 AND tdt_bus_area_id=74,606,
			 * IIF(tdt_bus_unit_id=43 AND tdt_bus_area_id=75,614,
			 * IIF(tdt_bus_unit_id=40 AND tdt_bus_area_id=71,597))))))))))
			 */
			// Setting Application ID

			String emailString[] = alert.split(" ");
			logger.info("Config Array : " + Arrays.toString(emailString));

			// Handled:
			/*
			 * OSS- Open Systems
			 * 
			 * [EXTERNAL] CDC-APP-PRD�-�Event Occured on Application CVS.com,
			 * Script:DrugChecks, Transaction:
			 * 020_CVS_DrugChecks_DrugInteraction, Trigger Cause: 2 out of 2
			 * transactions failed., Location:
			 * DataCenter_Scottsdale_2:10-23-2018 12:27:42
			 * 
			 * [[EXTERNAL], CDC-APP-PRD�-�Event, Occured, on, Application,
			 * CVS.com,, Script:DrugChecks,, Transaction:,
			 * 020_CVS_DrugChecks_DrugInteraction,, Trigger, Cause:, 2, out, of,
			 * 2, transactions, failed.,, Location:, DataCenter_Scottsdale_2]
			 * 
			 * [EXTERNAL] OSSTCS-ISOS�-�Event Occured on Application ESignature
			 * rri2exeapa1 Database Query
			 * rxgop1-QID11-Query-EsigRqustError-Last30Min-Count [[EXTERNAL],
			 * OSSTCS-ISOS�-�Event, Occured, on, Application, ESignature,
			 * rri2exeapa1, Database, Query,
			 * rxgop1-QID11-Query-EsigRqustError-Last30Min-Count]
			 * 
			 * 
			 * [EXTERNAL] OSSTCS-ISOS�-�102018084935616 CRITICAL event on
			 * mri1batpw4v job meme181d SendQueue has exceed its average
			 * execution time
			 * 
			 * [[EXTERNAL], OSSTCS-ISOS�-�102018084935616, CRITICAL, event, on,
			 * mri1batpw4v, job, meme181d, SendQueue, has, exceed, its, average,
			 * execution, time]
			 * 
			 * [EXTERNAL] OSSTCS-ISOS�-�101618038681042 CRITICAL event on
			 * eri1etlapa1d lxrd002d.sh lxrd002d ended NOTOK!
			 * 
			 * [[EXTERNAL], OSSTCS-ISOS�-�101618038681042, CRITICAL, event, on,
			 * eri1etlapa1d, lxrd002d.sh, lxrd002d, ended, NOTOK!]
			 * 
			 * 
			 * 
			 * [EXTERNAL] PS OSS OPEN SYSTEMS�-�101918719229105 CRITICAL event
			 * on Splunk_Retail ICE_Order_Error_Percent_Alert -
			 * SearchResult=https://rri2spshpl6v:8000/app/EnterpriseDigital/@go?
			 * sid=
			 * scheduler__scher__EnterpriseDigital__RMD5641cf1aa9710ad15_at_1540004400_1294_0B778E98
			 * -71EB-417C-AE9F-A74E6B3C60F2 [Posteifmsg Event]
			 * 
			 * [[EXTERNAL], PS, OSS, OPEN, SYSTEMS�-�101918719229105, CRITICAL,
			 * event, on, Splunk_Retail, ICE_Order_Error_Percent_Alert, -,
			 * SearchResult=https://rri2spshpl6v:8000/app/EnterpriseDigital/@go?
			 * sid=
			 * scheduler__scher__EnterpriseDigital__RMD5641cf1aa9710ad15_at_1540004400_1294_0B778E98
			 * -71EB-417C-AE9F-A74E6B3C60F2, [Posteifmsg, Event]]
			 * 
			 * 
			 * 
			 * [EXTERNAL] PS IS CORP SYSTEM ASSET
			 * MANAGER-EMAIL�-�101518037645021 WARNING event on rri1hpcipw1v
			 * AD-ITAM.bat amkn005d is running longer than normal.
			 * 
			 * [[EXTERNAL], PS, IS, CORP, SYSTEM, ASSET,
			 * MANAGER-EMAIL�-�101518037645021, WARNING, event, on,
			 * rri1hpcipw1v, AD-ITAM.bat, amkn005d, is, running, longer, than,
			 * normal.]
			 * 
			 * 
			 * [EXTERNAL] ESL DIGITAL ICE-EMAIL�-�102018084245447 WARNING event
			 * on rri2eslrpa2 Datapower System Load Avg is above 60 for two
			 * consecutive 5 minute intervals on BN:pe-dp2:DPS
			 * 
			 * [[EXTERNAL], ESL, DIGITAL, ICE-EMAIL�-�102018084245447, WARNING,
			 * event, on, rri2eslrpa2, Datapower, System, Load, Avg, is, above,
			 * 60, for, two, consecutive, 5, minute, intervals, on,
			 * BN:pe-dp2:DPS]
			 * 
			 * 
			 * 
			 * [EXTERNAL] TPMS UNIX BATCH�-�102218073420040 CRITICAL event on
			 * tpms-bat tptm071d_PLSQL_PROC_WOFF.sh tptm071d has not started
			 * [[EXTERNAL], TPMS, UNIX, BATCH�-�102218073420040, CRITICAL,
			 * event, on, tpms-bat, tptm071d_PLSQL_PROC_WOFF.sh, tptm071d, has,
			 * not, started]
			 * 
			 * 
			 * DW/RXC
			 * 
			 * [EXTERNAL] PS GENERAL MKTCR ANALYTICS�-�102318079182735 FATAL
			 * event on rri1crmapa1a Splunk Alert - CRM Legacy - Apache GetCust
			 * AvgRespTimeMs - avg_resp_time_ms:1734.0716837983357 [Posteifmsg
			 * Event]
			 * 
			 * [[EXTERNAL], PS, GENERAL, MKTCR, ANALYTICS�-�102318079182735,
			 * FATAL, event, on, rri1crmapa1a, Splunk, Alert, -, CRM, Legacy, -,
			 * Apache, GetCust, AvgRespTimeMs, -,
			 * avg_resp_time_ms:1734.0716837983357, [Posteifmsg, Event]]
			 * 
			 * 
			 * ----------------------------------------------------
			 * 
			 * [EXTERNAL] DW-BATCH�-�102318088234169 FATAL event on rri1crmapa1a
			 * Splunk Alert - CRM Legacy - Apache GetCust AvgRespTimeMs -
			 * avg_resp_time_ms:1734.0716837983357 [Posteifmsg Event]
			 * 
			 * [[EXTERNAL], DW-BATCH�-�102318088234169, FATAL, event, on,
			 * rri1crmapa1a, Splunk, Alert, -, CRM, Legacy, -, Apache, GetCust,
			 * AvgRespTimeMs, -, avg_resp_time_ms:1734.0716837983357,
			 * [Posteifmsg, Event]]
			 * 
			 * 
			 * 
			 * [EXTERNAL] DW-BATCH�-�102318188907122 CRITICAL event on crm-dw
			 * twrm140d.sh twrm140d02 has not started. [[EXTERNAL],
			 * DW-BATCH�-�102318188907122, CRITICAL, event, on, crm-dw,
			 * twrm140d.sh, twrm140d02, has, not, started.]
			 * 
			 * 
			 * 
			 * [EXTERNAL] RXC-BATCH�-�102318077313177 CRITICAL event on
			 * rri1rxbtpa52 mixr090d_PartitionPurge.sh job mixr090d8-RI has not
			 * completed or running long!. Please engage DBA to take trace for
			 * analysis [[EXTERNAL], RXC-BATCH�-�102318077313177, CRITICAL,
			 * event, on, rri1rxbtpa52, mixr090d_PartitionPurge.sh, job,
			 * mixr090d8-RI, has, not, completed, or, running, long!., Please,
			 * engage, DBA, to, take, trace, for, analysis]
			 * 
			 * 
			 * MF - [EXTERNAL] PS OSS MAINFRAME�-�102318231549637 CRITICAL event
			 * on rri2sapepa3 ZEAP028D_enh_E048 zeap028d ended NOTOK!
			 * [[EXTERNAL], PS, OSS, MAINFRAME�-�102318231549637, CRITICAL,
			 * event, on, rri2sapepa3, ZEAP028D_enh_E048, zeap028d, ended,
			 * NOTOK!]
			 * 
			 * 
			 * 
			 * [EXTERNAL] IM7566308 p1 min clin call center busy 800 242 8077
			 * bridge 615 7601 [[EXTERNAL], IM7566308, p1, min, clin, call,
			 * center, busy, 800, 242, 8077, bridge, 615, 7601]
			 */
			if ((emailString[1].contains("OSSTCS-ISOS") || emailString[1].contains("CDC-APP-PRD")
					|| (emailString[1].equals("PS") && emailString[2].equals("OSS") && emailString[3].equals("OPEN")
							&& emailString[4].substring(0, 7).equals("SYSTEMS")))) {
				if (emailString[6].equals("event")) {
					taskDetails.setTdt_configurable_item(emailString[8]);
				} else {
					taskDetails.setTdt_configurable_item(emailString[6]);
				}
				taskDetails.setTdt_logged_by("MXMX016D");
				taskDetails.setTdt_upd_by("MXMX016D");
				taskDetails.setTdt_bus_area_id(50);
				taskDetails.setTdt_bus_unit_id(22);
				if (emailString[2].equals("CRITICAL")) {
					taskDetails.setTdt_task_svrty_2("Critical");
				} else if (emailString[2].equals("FATAL")) {
					taskDetails.setTdt_task_svrty_2("Fatal");
				} else if (emailString[2].equals("WARNING")) {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				} else if (emailString[5].equals("CRITICAL")) {
					taskDetails.setTdt_task_svrty_2("Critical");
				} else if (emailString[5].equals("event")) {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				} else if (emailString[5].equals("FATAL")) {
					taskDetails.setTdt_task_svrty_2("Fatal");
				} else {
					taskDetails.setTdt_task_svrty_2("Critical");
				}
			} else if (emailString[1].equals("PS") && emailString[2].equals("IS") && emailString[3].equals("CORP")
					&& emailString[4].equals("SYSTEM") && emailString[5].equals("ASSET")) {
				taskDetails.setTdt_configurable_item(emailString[12]);
				taskDetails.setTdt_logged_by("MXMX016D");
				taskDetails.setTdt_upd_by("MXMX016D");
				taskDetails.setTdt_bus_area_id(50);// change
				taskDetails.setTdt_bus_unit_id(22);

				if (emailString[7].equals("WARNING")) {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				} else if (emailString[7].equals("CRITICAL")) {
					taskDetails.setTdt_task_svrty_2("Critical");
				} else if (emailString[7].equals("FATAL")) {
					taskDetails.setTdt_task_svrty_2("Fatal");
				} else {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				}

			} else if (emailString[1].equals("PS") && emailString[2].equals("RE") && emailString[3].equals("OPEN")
					&& emailString[4].contains("SYSTEMS-EMAIL")) {
				taskDetails.setTdt_configurable_item(emailString[12]);
				taskDetails.setTdt_logged_by("MXMX016D");
				taskDetails.setTdt_upd_by("MXMX016D");
				taskDetails.setTdt_bus_area_id(50);// change
				taskDetails.setTdt_bus_unit_id(22);

				if (emailString[7].equals("WARNING")) {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				} else if (emailString[7].equals("CRITICAL")) {
					taskDetails.setTdt_task_svrty_2("Critical");
				} else if (emailString[7].equals("FATAL")) {
					taskDetails.setTdt_task_svrty_2("Fatal");
				} else {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				}

			} else if ((emailString[1].equals("ESL") && emailString[2].equals("DIGITAL")
					&& emailString[3].contains("ICE-EMAIL")) || emailString[1].contains("IT-EBUSINESS-ICE-API")
					|| emailString[1].contains("ICET-ALERTS")) {
				taskDetails.setTdt_configurable_item(emailString[7]);
				taskDetails.setTdt_logged_by("MXMX016D");
				taskDetails.setTdt_upd_by("MXMX016D");
				taskDetails.setTdt_bus_area_id(50);
				taskDetails.setTdt_bus_unit_id(22);

				if (emailString[4].equals("WARNING")) {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				} else if (emailString[4].equals("CRITICAL")) {
					taskDetails.setTdt_task_svrty_2("Critical");
				} else if (emailString[4].equals("FATAL")) {
					taskDetails.setTdt_task_svrty_2("Fatal");
				} else {
					taskDetails.setTdt_task_svrty_2("Critical");
				}
			} else if (emailString[1].equals("TPMS") && emailString[2].equals("UNIX")
					&& emailString[3].contains("BATCH")) {
				taskDetails.setTdt_configurable_item(emailString[9]);
				taskDetails.setTdt_logged_by("MXMX016D");
				taskDetails.setTdt_upd_by("MXMX016D");
				taskDetails.setTdt_bus_area_id(58);
				taskDetails.setTdt_bus_unit_id(31);

				if (emailString[4].equals("WARNING")) {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				} else if (emailString[4].equals("CRITICAL")) {
					taskDetails.setTdt_task_svrty_2("Critical");
				} else if (emailString[4].equals("FATAL")) {
					taskDetails.setTdt_task_svrty_2("Fatal");
				} else {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				}
			} else if (emailString[1].equals("PS") && emailString[2].equals("GENERAL") && emailString[3].equals("MKTCR")
					&& emailString[4].contains("ANALYTICS")) {
				taskDetails.setTdt_configurable_item(emailString[8]);
				taskDetails.setTdt_logged_by("MXMX018D");
				taskDetails.setTdt_upd_by("MXMX018D");
				taskDetails.setTdt_bus_area_id(9);
				taskDetails.setTdt_bus_unit_id(9);

				if (emailString[5].equals("WARNING")) {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				} else if (emailString[5].equals("CRITICAL")) {
					taskDetails.setTdt_task_svrty_2("Critical");
				} else if (emailString[5].equals("FATAL")) {
					taskDetails.setTdt_task_svrty_2("Fatal");
				} else {
					taskDetails.setTdt_task_svrty_2("Critical");// Changed.
				}
			} else if (emailString[1].contains("DW-BATCH") || alert.contains("PS OSS ANALYTICS")) {
				taskDetails.setTdt_configurable_item(emailString[6]);
				taskDetails.setTdt_logged_by("MXMX018D");
				taskDetails.setTdt_upd_by("MXMX018D");
				taskDetails.setTdt_bus_area_id(9);
				taskDetails.setTdt_bus_unit_id(9);

				if (emailString[2].equals("WARNING")) {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				} else if (emailString[2].equals("CRITICAL")) {
					taskDetails.setTdt_task_svrty_2("Critical");
				} else if (emailString[2].equals("FATAL")) {
					taskDetails.setTdt_task_svrty_2("Fatal");
				} else {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				}

			} else if (emailString[1].contains("RXC-BATCH")) {
				taskDetails.setTdt_configurable_item(emailString[6]);
				taskDetails.setTdt_logged_by("MXMX019D");
				taskDetails.setTdt_upd_by("MXMX019D");
				taskDetails.setTdt_bus_area_id(51);
				taskDetails.setTdt_bus_unit_id(27);

				if (emailString[2].equals("WARNING")) {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				} else if (emailString[2].equals("CRITICAL")) {
					taskDetails.setTdt_task_svrty_2("Critical");
				} else if (emailString[2].equals("FATAL")) {
					taskDetails.setTdt_task_svrty_2("Fatal");
				} else {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				}

			} else if (reciepient.equals("rxc_coord_edl@cvscaremark.com") || emailString[1].contains("RXC-COORD")
					|| emailString[1].contains("RXC - APP SUPPORT")) {
				taskDetails.setTdt_configurable_item(emailString[5]);
				taskDetails.setTdt_logged_by("MXMX017D");
				taskDetails.setTdt_upd_by("MXMX017D");
				taskDetails.setTdt_bus_area_id(88);
				taskDetails.setTdt_bus_unit_id(54);

				if (emailString[2].equals("WARNING")) {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				} else if (emailString[2].equals("CRITICAL")) {
					taskDetails.setTdt_task_svrty_2("Critical");
				} else if (emailString[2].equals("FATAL")) {
					taskDetails.setTdt_task_svrty_2("Fatal");
				} else {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				}

			} else if (emailString[1].equals("PS") && emailString[2].contains("OSS")
					&& emailString[3].contains("MAINFRAME")) {
				taskDetails.setTdt_configurable_item(emailString[9]);
				taskDetails.setTdt_logged_by("MXMX020D");
				taskDetails.setTdt_upd_by("MXMX020D");
				taskDetails.setTdt_bus_area_id(12);
				taskDetails.setTdt_bus_unit_id(8);
				if (emailString[4].equals("WARNING")) {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				} else if (emailString[4].equals("CRITICAL")) {
					taskDetails.setTdt_task_svrty_2("Critical");
				} else if (emailString[4].equals("FATAL")) {
					taskDetails.setTdt_task_svrty_2("Fatal");
				} else {
					taskDetails.setTdt_task_svrty_2("Non-Critical");
				}
			} else {
				taskDetails.setTdt_configurable_item(emailString[7]);
				taskDetails.setTdt_logged_by("MXMX016D");
				taskDetails.setTdt_upd_by("MXMX016D");
				taskDetails.setTdt_bus_area_id(50);
				taskDetails.setTdt_bus_unit_id(22);
				taskDetails.setTdt_task_svrty_2("Non-Critical");
			}

			if (taskDetails.getTdt_bus_area_id() == 9 && taskDetails.getTdt_bus_unit_id() == 9) {
				taskDetails.setTdt_appln_id(640);// Valid DW
			} else if (taskDetails.getTdt_bus_area_id() == 50 && taskDetails.getTdt_bus_unit_id() == 22) {
				if ((emailString[1].equals("ESL") && emailString[2].equals("DIGITAL")
						&& emailString[3].contains("ICE-EMAIL")) || emailString[1].contains("IT-EBUSINESS-ICE-API")) {
					taskDetails.setTdt_appln_id(663);
				} else {
					taskDetails.setTdt_appln_id(372);
				} // valid
			} else if (taskDetails.getTdt_bus_area_id() == 12 && taskDetails.getTdt_bus_unit_id() == 8) {
				taskDetails.setTdt_appln_id(11);// valid MF
			} else if (taskDetails.getTdt_bus_area_id() == 58 && taskDetails.getTdt_bus_unit_id() == 31) {
				taskDetails.setTdt_appln_id(551);// valid
			} else if (taskDetails.getTdt_bus_area_id() == 51 && taskDetails.getTdt_bus_unit_id() == 27) {
				taskDetails.setTdt_appln_id(620);// valid RXC
			} else if (taskDetails.getTdt_bus_area_id() == 88 && taskDetails.getTdt_bus_unit_id() == 54) {
				taskDetails.setTdt_appln_id(628);// valid RXC App
			} else {
				taskDetails.setTdt_appln_id(372);
			}
			// }else if(taskDetails.getTdt_bus_area_id()==6 &&
			// taskDetails.getTdt_bus_unit_id()==7){
			// taskDetails.setTdt_appln_id(563);
			// }else if(taskDetails.getTdt_bus_area_id()==31 &&
			// taskDetails.getTdt_bus_unit_id()==58){
			// taskDetails.setTdt_appln_id(551);
			// }else if(taskDetails.getTdt_bus_area_id()==32 &&
			// taskDetails.getTdt_bus_unit_id()==59){
			// taskDetails.setTdt_appln_id(525);
			// }else if(taskDetails.getTdt_bus_area_id()==54 &&
			// taskDetails.getTdt_bus_unit_id()==88){
			// taskDetails.setTdt_appln_id(628);
			// }else if(taskDetails.getTdt_bus_area_id()==42 &&
			// taskDetails.getTdt_bus_unit_id()==74){
			// taskDetails.setTdt_appln_id(606);
			// }else if(taskDetails.getTdt_bus_area_id()==43 &&
			// taskDetails.getTdt_bus_unit_id()==75){
			// taskDetails.setTdt_appln_id(614);
			// }else if(taskDetails.getTdt_bus_area_id()==40 &&
			// taskDetails.getTdt_bus_unit_id()==71){
			// taskDetails.setTdt_appln_id(597);

			taskDetailsList.add(taskDetails);

			logger.info("Object :" + taskDetails.toString());
		} catch (Exception g) {
			logger.error("Not able to process the mail processing.");
			logger.error(g.getMessage(), g);
			try {
				SendEmail.sendErrorNotification(g);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}

	}

	public void processTaskEventDetailsTable(List<TaskDetails> taskDetails) {
		logger.info("Called processTaskEventDetailsTable() method to extract fields for TaskEventDetails table.");
		try {
			taskDetails.stream().forEach(object -> {
				TaskEventDetails taskEventDetails = new TaskEventDetails();
				taskEventDetails.setTed_event_root_cause_id(-1);
				taskEventDetails.setTed_upd_by(object.getTdt_upd_by());
				taskEventDetails.setTed_upd_time(sysdate);
				taskEventDetails.setTed_event_rec_status_id(7);
				logger.info("Object :" + taskEventDetails.toString());
				taskEventDetailsList.add(taskEventDetails);
			});
		} catch (Exception g) {
			logger.error("Not able to process the mail processing.");
			logger.error(g.getMessage(), g);
			try {
				SendEmail.sendErrorNotification(g);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
	}

}
