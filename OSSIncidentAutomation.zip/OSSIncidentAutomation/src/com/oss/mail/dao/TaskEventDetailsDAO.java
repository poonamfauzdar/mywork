package com.oss.mail.dao;

import java.util.List;

import com.oss.mail.beans.TaskEventDetails;

public interface TaskEventDetailsDAO {

	public TaskEventDetails addTaskEventDetails(TaskEventDetails taskEventDetails);

	public TaskEventDetails updateTaskEventDetails(TaskEventDetails taskEventDetails);

	public List<TaskEventDetails> listTaskEventDetails();

	public TaskEventDetails getTaskEventDetailsById(Integer ted_task_id);

	public void removeTaskEventDetails(Integer ted_task_id);
}
