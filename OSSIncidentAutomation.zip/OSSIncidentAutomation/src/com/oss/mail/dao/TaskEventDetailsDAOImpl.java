package com.oss.mail.dao;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.oss.mail.beans.TaskEventDetails;
import com.oss.mail.dao.TaskEventDetailsDAO;
import com.oss.mail.util.SendEmail;

@Repository
public class TaskEventDetailsDAOImpl implements TaskEventDetailsDAO {

	static Logger logger = LogManager.getLogger(TaskEventDetailsDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		logger.info("called setSessionFactory() to setting up session factory");
		this.sessionFactory = sessionFactory;
	}

	@Override
	public TaskEventDetails addTaskEventDetails(TaskEventDetails taskEventDetails) {
		logger.info("called addTaskEventDetails()");
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			session.save(taskEventDetails);
			session.getTransaction().commit();
			session.close();
		} catch (Exception e) {
			session.close();
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return taskEventDetails;
	}

	@Override
	public TaskEventDetails updateTaskEventDetails(TaskEventDetails taskEventDetails) {
		logger.info("called updateTaskEventDetails()");
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			session.update(taskEventDetails);
			session.getTransaction().commit();
			session.close();
		} catch (Exception e) {
			session.close();
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return taskEventDetails;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<TaskEventDetails> listTaskEventDetails() {
		logger.info("called listTaskEventDetails()");
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			List<TaskEventDetails> list = session.createQuery("from TaskEventDetails").list();
			session.close();
			return list;
		} catch (Exception e) {
			session.close();
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return null;
	}

	@Override
	@SuppressWarnings("unchecked")
	public TaskEventDetails getTaskEventDetailsById(Integer ted_task_id) {
		logger.info("called getTaskEventDetailsById() for ted_task_id : " + ted_task_id);
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			List<TaskEventDetails> list = session.createQuery("from TaskEventDetails t where t.id = :ted_task_Id")
					.setParameter("ted_task_Id", ted_task_id).list();
			session.close();
			return list.size() > 0 ? (TaskEventDetails) list.get(0) : null;
		} catch (Exception e) {
			session.close();
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return null;
	}

	@Override
	public void removeTaskEventDetails(Integer ted_task_id) {
		logger.info("called removeTaskEventDetails() for ted_task_id : " + ted_task_id);
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			TaskEventDetails tdt = (TaskEventDetails) session.load(TaskEventDetails.class, ted_task_id);
			if (null != tdt) {
				session.delete(tdt);
			}
			session.getTransaction().commit();
			session.close();
		} catch (Exception e) {
			session.close();
			logger.error(e.getMessage(), e);
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
	}

}
