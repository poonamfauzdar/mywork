package com.oss.mail.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.id.IdentifierGenerationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.oss.mail.beans.TaskDetails;
import com.oss.mail.beans.TaskEventDetails;
import com.oss.mail.util.SendEmail;

@Repository
public class DBBulkInsertionDAOImpl implements DBBulkInsertionDAO {

	static Logger logger = LogManager.getLogger(DBBulkInsertionDAOImpl.class.getName());

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<TaskDetails> insertBulkData(List<TaskDetails> taskDetailsList,
			List<TaskEventDetails> taskEventDetailsList) {
		logger.info("insertBulkData() has been invoked from DBBulkInsertionDAOImpl.");
		List<TaskDetails> resultTaskDetails = new ArrayList<TaskDetails>();
		List<Integer> ids = new ArrayList<Integer>();
		logger.info("Opening Hibernate Session.");
		Session session = sessionFactory.getCurrentSession();
		logger.info("Begin Hibernate Transaction.");
		try {
			session.beginTransaction();
			logger.info("Streaming and saving TaskDetails data from List into session");
			taskDetailsList.forEach(taskDetails -> {
				taskDetails.setTdt_task_id(((Integer) session.save(taskDetails)));
				resultTaskDetails.add(taskDetails);
				if (resultTaskDetails.size() % 20 == 0) {
					logger.info("Flushing and clearing session, total records : " + resultTaskDetails.size());
					session.flush();
					session.clear();
				}
			});
			logger.info("Flushing and clearing session, total records : " + resultTaskDetails.size());
			session.flush();
			session.clear();
			logger.info("Setting up previously generated ted_task_id to TaskEventDetails List.");
			for (int i = 0; i < resultTaskDetails.size(); i++) {
				taskEventDetailsList.get(i).setTed_task_id(resultTaskDetails.get(i).getTdt_task_id());
			}
			logger.info("Streaming and saving TaskDetails data from List into session");
			taskEventDetailsList.forEach(taskEventDetails -> {
				ids.add((Integer) session.save(taskEventDetails));
				if (ids.size() % 20 == 0) {
					logger.info("Flushing and clearing session, total records : " + ids.size());
					session.flush();
					session.clear();
				}
			});
			logger.info("Flushing and clearing session, total records : " + ids.size());
			session.flush();
			session.clear();
			logger.info("Getting and Commiting the transaction and closing the session.");
			session.getTransaction().commit();
			return resultTaskDetails;
		} catch (IdentifierGenerationException i) {
			logger.error(i.getMessage(), i);
			try {
				SendEmail.sendErrorNotification(i);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
			session.close();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			session.close();
			try {
				SendEmail.sendErrorNotification(e);
			} catch (IOException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}
		return resultTaskDetails;
	}

}
