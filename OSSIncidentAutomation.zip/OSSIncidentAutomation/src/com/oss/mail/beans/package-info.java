/**
 * 
 */
/**
 * @author asaxena2
 *
 */
package com.oss.mail.beans;