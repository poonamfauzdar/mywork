package com.oss.mail.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "task_details", schema = "ASM_OSS.dbo") // PRODUCTION
// @Table(name = "[task_details]", schema = "[ASMDB004].[dbo]")//DEVELOPMENT
public class TaskDetails {

	@Id
	@Column(name = "tdt_task_id")
	@GeneratedValue
	private Integer tdt_task_id;
	@Column(name = "tdt_appln_id")
	private Integer tdt_appln_id;
	@Column(name = "tdt_tech_id")
	private Integer tdt_tech_id;
	@Column(name = "tdt_task_cat_id")
	private Integer tdt_task_cat_id;
	@Column(name = "tdt_tsk_sub_cat_id")
	private Integer tdt_tsk_sub_cat_id;
	@Column(name = "tdt_eng_sub_cat_id")
	private Integer tdt_eng_sub_cat_id;
	@Column(name = "tdt_EA_tkt")
	private String tdt_EA_tkt;
	@Column(name = "tdt_pvcs_num")
	private String tdt_pvcs_num;
	@Column(name = "tdt_task_svrty")
	private Integer tdt_task_svrty;
	@Column(name = "tdt_pblm_desc")
	private String tdt_pblm_desc;
	@Column(name = "tdt_logged_by")
	private String tdt_logged_by;
	@Column(name = "tdt_resol_status_id")
	private Integer tdt_resol_status_id;
	@Column(name = "tdt_pln_startdate")
	private String tdt_pln_startdate;
	@Column(name = "tdt_pln_enddate")
	private String tdt_pln_enddate;
	@Column(name = "tdt_act_stdate")
	private String tdt_act_stdate;
	@Column(name = "tdt_act_enddate")
	private String tdt_act_enddate;
	@Column(name = "tdt_prjtd_effort")
	private double tdt_prjtd_effort;
	@Column(name = "tdt_act_effort")
	private double tdt_act_effort;
	@Column(name = "tdt_pblm_soln")
	private String tdt_pblm_soln;
	@Column(name = "tdt_upd_by")
	private String tdt_upd_by;
	@Column(name = "tdt_upd_time")
	private String tdt_upd_time;
	@Column(name = "tdt_niku_flag")
	private String tdt_niku_flag;
	@Column(name = "tdt_event_notif_dt")
	private String tdt_event_notif_dt;
	@Column(name = "tdt_ext_sys_id")
	private String tdt_ext_sys_id;
	@Column(name = "tdt_notice_time")
	private String tdt_notice_time;
	@Column(name = "tdt_shift")
	private Integer tdt_shift;
	@Column(name = "tdt_assigned_to")
	private String tdt_assigned_to;
	@Column(name = "tdt_incident_type")
	private Integer tdt_incident_type;
	@Column(name = "tdt_configurable_item")
	private String tdt_configurable_item;
	@Column(name = "tdt_change_related")
	private String tdt_change_related;
	@Column(name = "tdt_ccb_num")
	private String tdt_ccb_num;
	@Column(name = "tdt_outage_related")
	private String tdt_outage_related;
	@Column(name = "tdt_esc_to_cvs")
	private String tdt_esc_to_cvs;
	@Column(name = "tdt_esc_time")
	private String tdt_esc_time;
	@Column(name = "tdt_esc_reason")
	private String tdt_esc_reason;
	@Column(name = "tdt_resolution_time")
	private String tdt_resolution_time;
	@Column(name = "tdt_owner_to")
	private String tdt_owner_to;
	@Column(name = "tdt_remediation")
	private String tdt_remediation;
	@Column(name = "tdt_ccb_num_2")
	private String tdt_ccb_num_2;
	@Column(name = "tdt_task_svrty_2")
	private String tdt_task_svrty_2;
	@Column(name = "tdt_recovery_sol")
	private String tdt_recovery_sol;
	@Column(name = "tdt_root_cause_no")
	private Integer tdt_root_cause_no;
	@Column(name = "tdt_engmt_id")
	private Integer tdt_engmt_id;
	@Column(name = "tdt_bus_unit_id")
	private Integer tdt_bus_unit_id;
	@Column(name = "tdt_bus_area_id")
	private Integer tdt_bus_area_id;
	@Column(name = "tdt_recovery_ccb")
	private String tdt_recovery_ccb;
	@Column(name = "tdt_remediation_req")
	private String tdt_remediation_req;
	@Column(name = "tdt_active")
	private String tdt_active;
	@Column(name = "tdt_freeze")
	private String tdt_freeze;
	@Column(name = "tdt_high_level_cause")
	private Integer tdt_high_level_cause;
	@Column(name = "template_flag")
	private String template_flag;
	@Column(name = "tdt_incidents_count")
	private Integer tdt_incidents_count;
	@Column(name = "tdt_sen_count")
	private Integer tdt_sen_count;
	@Column(name = "tdt_vend_id")
	private Integer tdt_vend_id;
	@Column(name = "tdt_esc_to_onsite_id")
	private Integer tdt_esc_to_onsite_id;
	@Column(name = "tdt_reason_esc_onsite_id")
	private Integer tdt_reason_esc_onsite_id;
	@Column(name = "tdt_esc_time_onsite")
	private String tdt_esc_time_onsite;
	@Column(name = "tdt_unixdba_number")
	private String tdt_unixdba_number;
	@Column(name = "tdt_defect_id")
	private String tdt_defect_id;
	@Column(name = "Actual_Effort")
	private String Actual_Effort;
	@Column(name = "No_Of_Resources")
	private String No_Of_Resources;
	@Column(name = "Future_Column1")
	private Integer Future_Column1;
	@Column(name = "Future_Column2")
	private String Future_Column2;
	@Column(name = "Future_Column3")
	private String Future_Column3;
	@Column(name = "Future_Column4")
	private String Future_Column4;

	public TaskDetails() {
	}

	public TaskDetails(Integer tdt_task_id, Integer tdt_appln_id, Integer tdt_tech_id, Integer tdt_task_cat_id,
			Integer tdt_tsk_sub_cat_id, Integer tdt_eng_sub_cat_id, String tdt_EA_tkt, String tdt_pvcs_num,
			Integer tdt_task_svrty, String tdt_pblm_desc, String tdt_logged_by, Integer tdt_resol_status_id,
			String tdt_pln_startdate, String tdt_pln_enddate, String tdt_act_stdate, String tdt_act_enddate,
			double tdt_prjtd_effort, double tdt_act_effort, String tdt_pblm_soln, String tdt_upd_by,
			String tdt_upd_time, String tdt_niku_flag, String tdt_event_notif_dt, String tdt_ext_sys_id,
			String tdt_notice_time, Integer tdt_shift, String tdt_assigned_to, Integer tdt_incident_type,
			String tdt_configurable_item, String tdt_change_related, String tdt_ccb_num, String tdt_outage_related,
			String tdt_esc_to_cvs, String tdt_esc_time, String tdt_esc_reason, String tdt_resolution_time,
			String tdt_owner_to, String tdt_remediation, String tdt_ccb_num_2, String tdt_task_svrty_2,
			String tdt_recovery_sol, Integer tdt_root_cause_no, Integer tdt_engmt_id, Integer tdt_bus_unit_id,
			Integer tdt_bus_area_id, String tdt_recovery_ccb, String tdt_remediation_req, String tdt_active,
			String tdt_freeze, Integer tdt_high_level_cause, String template_flag, Integer tdt_incidents_count,
			Integer tdt_sen_count, Integer tdt_vend_id, Integer tdt_esc_to_onsite_id, Integer tdt_reason_esc_onsite_id,
			String tdt_esc_time_onsite, String tdt_unixdba_number, String tdt_defect_id, String actual_Effort,
			String no_Of_Resources, Integer future_Column1, String future_Column2, String future_Column3,
			String future_Column4) {
		this.tdt_task_id = tdt_task_id;
		this.tdt_appln_id = tdt_appln_id;
		this.tdt_tech_id = tdt_tech_id;
		this.tdt_task_cat_id = tdt_task_cat_id;
		this.tdt_tsk_sub_cat_id = tdt_tsk_sub_cat_id;
		this.tdt_eng_sub_cat_id = tdt_eng_sub_cat_id;
		this.tdt_EA_tkt = tdt_EA_tkt;
		this.tdt_pvcs_num = tdt_pvcs_num;
		this.tdt_task_svrty = tdt_task_svrty;
		this.tdt_pblm_desc = tdt_pblm_desc;
		this.tdt_logged_by = tdt_logged_by;
		this.tdt_resol_status_id = tdt_resol_status_id;
		this.tdt_pln_startdate = tdt_pln_startdate;
		this.tdt_pln_enddate = tdt_pln_enddate;
		this.tdt_act_stdate = tdt_act_stdate;
		this.tdt_act_enddate = tdt_act_enddate;
		this.tdt_prjtd_effort = tdt_prjtd_effort;
		this.tdt_act_effort = tdt_act_effort;
		this.tdt_pblm_soln = tdt_pblm_soln;
		this.tdt_upd_by = tdt_upd_by;
		this.tdt_upd_time = tdt_upd_time;
		this.tdt_niku_flag = tdt_niku_flag;
		this.tdt_event_notif_dt = tdt_event_notif_dt;
		this.tdt_ext_sys_id = tdt_ext_sys_id;
		this.tdt_notice_time = tdt_notice_time;
		this.tdt_shift = tdt_shift;
		this.tdt_assigned_to = tdt_assigned_to;
		this.tdt_incident_type = tdt_incident_type;
		this.tdt_configurable_item = tdt_configurable_item;
		this.tdt_change_related = tdt_change_related;
		this.tdt_ccb_num = tdt_ccb_num;
		this.tdt_outage_related = tdt_outage_related;
		this.tdt_esc_to_cvs = tdt_esc_to_cvs;
		this.tdt_esc_time = tdt_esc_time;
		this.tdt_esc_reason = tdt_esc_reason;
		this.tdt_resolution_time = tdt_resolution_time;
		this.tdt_owner_to = tdt_owner_to;
		this.tdt_remediation = tdt_remediation;
		this.tdt_ccb_num_2 = tdt_ccb_num_2;
		this.tdt_task_svrty_2 = tdt_task_svrty_2;
		this.tdt_recovery_sol = tdt_recovery_sol;
		this.tdt_root_cause_no = tdt_root_cause_no;
		this.tdt_engmt_id = tdt_engmt_id;
		this.tdt_bus_unit_id = tdt_bus_unit_id;
		this.tdt_bus_area_id = tdt_bus_area_id;
		this.tdt_recovery_ccb = tdt_recovery_ccb;
		this.tdt_remediation_req = tdt_remediation_req;
		this.tdt_active = tdt_active;
		this.tdt_freeze = tdt_freeze;
		this.tdt_high_level_cause = tdt_high_level_cause;
		this.template_flag = template_flag;
		this.tdt_incidents_count = tdt_incidents_count;
		this.tdt_sen_count = tdt_sen_count;
		this.tdt_vend_id = tdt_vend_id;
		this.tdt_esc_to_onsite_id = tdt_esc_to_onsite_id;
		this.tdt_reason_esc_onsite_id = tdt_reason_esc_onsite_id;
		this.tdt_esc_time_onsite = tdt_esc_time_onsite;
		this.tdt_unixdba_number = tdt_unixdba_number;
		this.tdt_defect_id = tdt_defect_id;
		Actual_Effort = actual_Effort;
		No_Of_Resources = no_Of_Resources;
		Future_Column1 = future_Column1;
		Future_Column2 = future_Column2;
		Future_Column3 = future_Column3;
		Future_Column4 = future_Column4;
	}

	public Integer getTdt_task_id() {
		return tdt_task_id;
	}

	public void setTdt_task_id(Integer tdt_task_id) {
		this.tdt_task_id = tdt_task_id;
	}

	public Integer getTdt_appln_id() {
		return tdt_appln_id;
	}

	public void setTdt_appln_id(Integer tdt_appln_id) {
		this.tdt_appln_id = tdt_appln_id;
	}

	public Integer getTdt_tech_id() {
		return tdt_tech_id;
	}

	public void setTdt_tech_id(Integer tdt_tech_id) {
		this.tdt_tech_id = tdt_tech_id;
	}

	public Integer getTdt_task_cat_id() {
		return tdt_task_cat_id;
	}

	public void setTdt_task_cat_id(Integer tdt_task_cat_id) {
		this.tdt_task_cat_id = tdt_task_cat_id;
	}

	public Integer getTdt_tsk_sub_cat_id() {
		return tdt_tsk_sub_cat_id;
	}

	public void setTdt_tsk_sub_cat_id(Integer tdt_tsk_sub_cat_id) {
		this.tdt_tsk_sub_cat_id = tdt_tsk_sub_cat_id;
	}

	public Integer getTdt_eng_sub_cat_id() {
		return tdt_eng_sub_cat_id;
	}

	public void setTdt_eng_sub_cat_id(Integer tdt_eng_sub_cat_id) {
		this.tdt_eng_sub_cat_id = tdt_eng_sub_cat_id;
	}

	public String getTdt_EA_tkt() {
		return tdt_EA_tkt;
	}

	public void setTdt_EA_tkt(String tdt_EA_tkt) {
		this.tdt_EA_tkt = tdt_EA_tkt;
	}

	public String getTdt_pvcs_num() {
		return tdt_pvcs_num;
	}

	public void setTdt_pvcs_num(String tdt_pvcs_num) {
		this.tdt_pvcs_num = tdt_pvcs_num;
	}

	public Integer getTdt_task_svrty() {
		return tdt_task_svrty;
	}

	public void setTdt_task_svrty(Integer tdt_task_svrty) {
		this.tdt_task_svrty = tdt_task_svrty;
	}

	public String getTdt_pblm_desc() {
		return tdt_pblm_desc;
	}

	public void setTdt_pblm_desc(String tdt_pblm_desc) {
		this.tdt_pblm_desc = tdt_pblm_desc;
	}

	public String getTdt_logged_by() {
		return tdt_logged_by;
	}

	public void setTdt_logged_by(String tdt_logged_by) {
		this.tdt_logged_by = tdt_logged_by;
	}

	public Integer getTdt_resol_status_id() {
		return tdt_resol_status_id;
	}

	public void setTdt_resol_status_id(Integer tdt_resol_status_id) {
		this.tdt_resol_status_id = tdt_resol_status_id;
	}

	public String getTdt_pln_startdate() {
		return tdt_pln_startdate;
	}

	public void setTdt_pln_startdate(String tdt_pln_startdate) {
		this.tdt_pln_startdate = tdt_pln_startdate;
	}

	public String getTdt_pln_enddate() {
		return tdt_pln_enddate;
	}

	public void setTdt_pln_enddate(String tdt_pln_enddate) {
		this.tdt_pln_enddate = tdt_pln_enddate;
	}

	public String getTdt_act_stdate() {
		return tdt_act_stdate;
	}

	public void setTdt_act_stdate(String tdt_act_stdate) {
		this.tdt_act_stdate = tdt_act_stdate;
	}

	public String getTdt_act_enddate() {
		return tdt_act_enddate;
	}

	public void setTdt_act_enddate(String tdt_act_enddate) {
		this.tdt_act_enddate = tdt_act_enddate;
	}

	public double getTdt_prjtd_effort() {
		return tdt_prjtd_effort;
	}

	public void setTdt_prjtd_effort(double tdt_prjtd_effort) {
		this.tdt_prjtd_effort = tdt_prjtd_effort;
	}

	public double getTdt_act_effort() {
		return tdt_act_effort;
	}

	public void setTdt_act_effort(double tdt_act_effort) {
		this.tdt_act_effort = tdt_act_effort;
	}

	public String getTdt_pblm_soln() {
		return tdt_pblm_soln;
	}

	public void setTdt_pblm_soln(String tdt_pblm_soln) {
		this.tdt_pblm_soln = tdt_pblm_soln;
	}

	public String getTdt_upd_by() {
		return tdt_upd_by;
	}

	public void setTdt_upd_by(String tdt_upd_by) {
		this.tdt_upd_by = tdt_upd_by;
	}

	public String getTdt_upd_time() {
		return tdt_upd_time;
	}

	public void setTdt_upd_time(String tdt_upd_time) {
		this.tdt_upd_time = tdt_upd_time;
	}

	public String getTdt_niku_flag() {
		return tdt_niku_flag;
	}

	public void setTdt_niku_flag(String tdt_niku_flag) {
		this.tdt_niku_flag = tdt_niku_flag;
	}

	public String getTdt_event_notif_dt() {
		return tdt_event_notif_dt;
	}

	public void setTdt_event_notif_dt(String tdt_event_notif_dt) {
		this.tdt_event_notif_dt = tdt_event_notif_dt;
	}

	public String getTdt_ext_sys_id() {
		return tdt_ext_sys_id;
	}

	public void setTdt_ext_sys_id(String tdt_ext_sys_id) {
		this.tdt_ext_sys_id = tdt_ext_sys_id;
	}

	public String getTdt_notice_time() {
		return tdt_notice_time;
	}

	public void setTdt_notice_time(String tdt_notice_time) {
		this.tdt_notice_time = tdt_notice_time;
	}

	public Integer getTdt_shift() {
		return tdt_shift;
	}

	public void setTdt_shift(Integer tdt_shift) {
		this.tdt_shift = tdt_shift;
	}

	public String getTdt_assigned_to() {
		return tdt_assigned_to;
	}

	public void setTdt_assigned_to(String tdt_assigned_to) {
		this.tdt_assigned_to = tdt_assigned_to;
	}

	public Integer getTdt_incident_type() {
		return tdt_incident_type;
	}

	public void setTdt_incident_type(Integer tdt_incident_type) {
		this.tdt_incident_type = tdt_incident_type;
	}

	public String getTdt_configurable_item() {
		return tdt_configurable_item;
	}

	public void setTdt_configurable_item(String tdt_configurable_item) {
		this.tdt_configurable_item = tdt_configurable_item;
	}

	public String getTdt_change_related() {
		return tdt_change_related;
	}

	public void setTdt_change_related(String tdt_change_related) {
		this.tdt_change_related = tdt_change_related;
	}

	public String getTdt_ccb_num() {
		return tdt_ccb_num;
	}

	public void setTdt_ccb_num(String tdt_ccb_num) {
		this.tdt_ccb_num = tdt_ccb_num;
	}

	public String getTdt_outage_related() {
		return tdt_outage_related;
	}

	public void setTdt_outage_related(String tdt_outage_related) {
		this.tdt_outage_related = tdt_outage_related;
	}

	public String getTdt_esc_to_cvs() {
		return tdt_esc_to_cvs;
	}

	public void setTdt_esc_to_cvs(String tdt_esc_to_cvs) {
		this.tdt_esc_to_cvs = tdt_esc_to_cvs;
	}

	public String getTdt_esc_time() {
		return tdt_esc_time;
	}

	public void setTdt_esc_time(String tdt_esc_time) {
		this.tdt_esc_time = tdt_esc_time;
	}

	public String getTdt_esc_reason() {
		return tdt_esc_reason;
	}

	public void setTdt_esc_reason(String tdt_esc_reason) {
		this.tdt_esc_reason = tdt_esc_reason;
	}

	public String getTdt_resolution_time() {
		return tdt_resolution_time;
	}

	public void setTdt_resolution_time(String tdt_resolution_time) {
		this.tdt_resolution_time = tdt_resolution_time;
	}

	public String getTdt_owner_to() {
		return tdt_owner_to;
	}

	public void setTdt_owner_to(String tdt_owner_to) {
		this.tdt_owner_to = tdt_owner_to;
	}

	public String getTdt_remediation() {
		return tdt_remediation;
	}

	public void setTdt_remediation(String tdt_remediation) {
		this.tdt_remediation = tdt_remediation;
	}

	public String getTdt_ccb_num_2() {
		return tdt_ccb_num_2;
	}

	public void setTdt_ccb_num_2(String tdt_ccb_num_2) {
		this.tdt_ccb_num_2 = tdt_ccb_num_2;
	}

	public String getTdt_task_svrty_2() {
		return tdt_task_svrty_2;
	}

	public void setTdt_task_svrty_2(String tdt_task_svrty_2) {
		this.tdt_task_svrty_2 = tdt_task_svrty_2;
	}

	public String getTdt_recovery_sol() {
		return tdt_recovery_sol;
	}

	public void setTdt_recovery_sol(String tdt_recovery_sol) {
		this.tdt_recovery_sol = tdt_recovery_sol;
	}

	public Integer getTdt_root_cause_no() {
		return tdt_root_cause_no;
	}

	public void setTdt_root_cause_no(Integer tdt_root_cause_no) {
		this.tdt_root_cause_no = tdt_root_cause_no;
	}

	public Integer getTdt_engmt_id() {
		return tdt_engmt_id;
	}

	public void setTdt_engmt_id(Integer tdt_engmt_id) {
		this.tdt_engmt_id = tdt_engmt_id;
	}

	public Integer getTdt_bus_unit_id() {
		return tdt_bus_unit_id;
	}

	public void setTdt_bus_unit_id(Integer tdt_bus_unit_id) {
		this.tdt_bus_unit_id = tdt_bus_unit_id;
	}

	public Integer getTdt_bus_area_id() {
		return tdt_bus_area_id;
	}

	public void setTdt_bus_area_id(Integer tdt_bus_area_id) {
		this.tdt_bus_area_id = tdt_bus_area_id;
	}

	public String getTdt_recovery_ccb() {
		return tdt_recovery_ccb;
	}

	public void setTdt_recovery_ccb(String tdt_recovery_ccb) {
		this.tdt_recovery_ccb = tdt_recovery_ccb;
	}

	public String getTdt_remediation_req() {
		return tdt_remediation_req;
	}

	public void setTdt_remediation_req(String tdt_remediation_req) {
		this.tdt_remediation_req = tdt_remediation_req;
	}

	public String getTdt_active() {
		return tdt_active;
	}

	public void setTdt_active(String tdt_active) {
		this.tdt_active = tdt_active;
	}

	public String getTdt_freeze() {
		return tdt_freeze;
	}

	public void setTdt_freeze(String tdt_freeze) {
		this.tdt_freeze = tdt_freeze;
	}

	public Integer getTdt_high_level_cause() {
		return tdt_high_level_cause;
	}

	public void setTdt_high_level_cause(Integer tdt_high_level_cause) {
		this.tdt_high_level_cause = tdt_high_level_cause;
	}

	public String getTemplate_flag() {
		return template_flag;
	}

	public void setTemplate_flag(String template_flag) {
		this.template_flag = template_flag;
	}

	public Integer getTdt_incidents_count() {
		return tdt_incidents_count;
	}

	public void setTdt_incidents_count(Integer tdt_incidents_count) {
		this.tdt_incidents_count = tdt_incidents_count;
	}

	public Integer getTdt_sen_count() {
		return tdt_sen_count;
	}

	public void setTdt_sen_count(Integer tdt_sen_count) {
		this.tdt_sen_count = tdt_sen_count;
	}

	public Integer getTdt_vend_id() {
		return tdt_vend_id;
	}

	public void setTdt_vend_id(Integer tdt_vend_id) {
		this.tdt_vend_id = tdt_vend_id;
	}

	public Integer getTdt_esc_to_onsite_id() {
		return tdt_esc_to_onsite_id;
	}

	public void setTdt_esc_to_onsite_id(Integer tdt_esc_to_onsite_id) {
		this.tdt_esc_to_onsite_id = tdt_esc_to_onsite_id;
	}

	public Integer getTdt_reason_esc_onsite_id() {
		return tdt_reason_esc_onsite_id;
	}

	public void setTdt_reason_esc_onsite_id(Integer tdt_reason_esc_onsite_id) {
		this.tdt_reason_esc_onsite_id = tdt_reason_esc_onsite_id;
	}

	public String getTdt_esc_time_onsite() {
		return tdt_esc_time_onsite;
	}

	public void setTdt_esc_time_onsite(String tdt_esc_time_onsite) {
		this.tdt_esc_time_onsite = tdt_esc_time_onsite;
	}

	public String getTdt_unixdba_number() {
		return tdt_unixdba_number;
	}

	public void setTdt_unixdba_number(String tdt_unixdba_number) {
		this.tdt_unixdba_number = tdt_unixdba_number;
	}

	public String getTdt_defect_id() {
		return tdt_defect_id;
	}

	public void setTdt_defect_id(String tdt_defect_id) {
		this.tdt_defect_id = tdt_defect_id;
	}

	public String getActual_Effort() {
		return Actual_Effort;
	}

	public void setActual_Effort(String actual_Effort) {
		Actual_Effort = actual_Effort;
	}

	public String getNo_Of_Resources() {
		return No_Of_Resources;
	}

	public void setNo_Of_Resources(String no_Of_Resources) {
		No_Of_Resources = no_Of_Resources;
	}

	public Integer getFuture_Column1() {
		return Future_Column1;
	}

	public void setFuture_Column1(Integer future_Column1) {
		Future_Column1 = future_Column1;
	}

	public String getFuture_Column2() {
		return Future_Column2;
	}

	public void setFuture_Column2(String future_Column2) {
		Future_Column2 = future_Column2;
	}

	public String getFuture_Column3() {
		return Future_Column3;
	}

	public void setFuture_Column3(String future_Column3) {
		Future_Column3 = future_Column3;
	}

	public String getFuture_Column4() {
		return Future_Column4;
	}

	public void setFuture_Column4(String future_Column4) {
		Future_Column4 = future_Column4;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Actual_Effort == null) ? 0 : Actual_Effort.hashCode());
		result = prime * result + ((Future_Column1 == null) ? 0 : Future_Column1.hashCode());
		result = prime * result + ((Future_Column2 == null) ? 0 : Future_Column2.hashCode());
		result = prime * result + ((Future_Column3 == null) ? 0 : Future_Column3.hashCode());
		result = prime * result + ((Future_Column4 == null) ? 0 : Future_Column4.hashCode());
		result = prime * result + ((No_Of_Resources == null) ? 0 : No_Of_Resources.hashCode());
		result = prime * result + ((tdt_EA_tkt == null) ? 0 : tdt_EA_tkt.hashCode());
		long temp;
		temp = Double.doubleToLongBits(tdt_act_effort);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((tdt_act_enddate == null) ? 0 : tdt_act_enddate.hashCode());
		result = prime * result + ((tdt_act_stdate == null) ? 0 : tdt_act_stdate.hashCode());
		result = prime * result + ((tdt_active == null) ? 0 : tdt_active.hashCode());
		result = prime * result + ((tdt_appln_id == null) ? 0 : tdt_appln_id.hashCode());
		result = prime * result + ((tdt_assigned_to == null) ? 0 : tdt_assigned_to.hashCode());
		result = prime * result + ((tdt_bus_area_id == null) ? 0 : tdt_bus_area_id.hashCode());
		result = prime * result + ((tdt_bus_unit_id == null) ? 0 : tdt_bus_unit_id.hashCode());
		result = prime * result + ((tdt_ccb_num == null) ? 0 : tdt_ccb_num.hashCode());
		result = prime * result + ((tdt_ccb_num_2 == null) ? 0 : tdt_ccb_num_2.hashCode());
		result = prime * result + ((tdt_change_related == null) ? 0 : tdt_change_related.hashCode());
		result = prime * result + ((tdt_configurable_item == null) ? 0 : tdt_configurable_item.hashCode());
		result = prime * result + ((tdt_defect_id == null) ? 0 : tdt_defect_id.hashCode());
		result = prime * result + ((tdt_eng_sub_cat_id == null) ? 0 : tdt_eng_sub_cat_id.hashCode());
		result = prime * result + ((tdt_engmt_id == null) ? 0 : tdt_engmt_id.hashCode());
		result = prime * result + ((tdt_esc_reason == null) ? 0 : tdt_esc_reason.hashCode());
		result = prime * result + ((tdt_esc_time == null) ? 0 : tdt_esc_time.hashCode());
		result = prime * result + ((tdt_esc_time_onsite == null) ? 0 : tdt_esc_time_onsite.hashCode());
		result = prime * result + ((tdt_esc_to_cvs == null) ? 0 : tdt_esc_to_cvs.hashCode());
		result = prime * result + ((tdt_esc_to_onsite_id == null) ? 0 : tdt_esc_to_onsite_id.hashCode());
		result = prime * result + ((tdt_event_notif_dt == null) ? 0 : tdt_event_notif_dt.hashCode());
		result = prime * result + ((tdt_ext_sys_id == null) ? 0 : tdt_ext_sys_id.hashCode());
		result = prime * result + ((tdt_freeze == null) ? 0 : tdt_freeze.hashCode());
		result = prime * result + ((tdt_high_level_cause == null) ? 0 : tdt_high_level_cause.hashCode());
		result = prime * result + ((tdt_incident_type == null) ? 0 : tdt_incident_type.hashCode());
		result = prime * result + ((tdt_incidents_count == null) ? 0 : tdt_incidents_count.hashCode());
		result = prime * result + ((tdt_logged_by == null) ? 0 : tdt_logged_by.hashCode());
		result = prime * result + ((tdt_niku_flag == null) ? 0 : tdt_niku_flag.hashCode());
		result = prime * result + ((tdt_notice_time == null) ? 0 : tdt_notice_time.hashCode());
		result = prime * result + ((tdt_outage_related == null) ? 0 : tdt_outage_related.hashCode());
		result = prime * result + ((tdt_owner_to == null) ? 0 : tdt_owner_to.hashCode());
		result = prime * result + ((tdt_pblm_desc == null) ? 0 : tdt_pblm_desc.hashCode());
		result = prime * result + ((tdt_pblm_soln == null) ? 0 : tdt_pblm_soln.hashCode());
		result = prime * result + ((tdt_pln_enddate == null) ? 0 : tdt_pln_enddate.hashCode());
		result = prime * result + ((tdt_pln_startdate == null) ? 0 : tdt_pln_startdate.hashCode());
		temp = Double.doubleToLongBits(tdt_prjtd_effort);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((tdt_pvcs_num == null) ? 0 : tdt_pvcs_num.hashCode());
		result = prime * result + ((tdt_reason_esc_onsite_id == null) ? 0 : tdt_reason_esc_onsite_id.hashCode());
		result = prime * result + ((tdt_recovery_ccb == null) ? 0 : tdt_recovery_ccb.hashCode());
		result = prime * result + ((tdt_recovery_sol == null) ? 0 : tdt_recovery_sol.hashCode());
		result = prime * result + ((tdt_remediation == null) ? 0 : tdt_remediation.hashCode());
		result = prime * result + ((tdt_remediation_req == null) ? 0 : tdt_remediation_req.hashCode());
		result = prime * result + ((tdt_resol_status_id == null) ? 0 : tdt_resol_status_id.hashCode());
		result = prime * result + ((tdt_resolution_time == null) ? 0 : tdt_resolution_time.hashCode());
		result = prime * result + ((tdt_root_cause_no == null) ? 0 : tdt_root_cause_no.hashCode());
		result = prime * result + ((tdt_sen_count == null) ? 0 : tdt_sen_count.hashCode());
		result = prime * result + ((tdt_shift == null) ? 0 : tdt_shift.hashCode());
		result = prime * result + ((tdt_task_cat_id == null) ? 0 : tdt_task_cat_id.hashCode());
		result = prime * result + ((tdt_task_id == null) ? 0 : tdt_task_id.hashCode());
		result = prime * result + ((tdt_task_svrty == null) ? 0 : tdt_task_svrty.hashCode());
		result = prime * result + ((tdt_task_svrty_2 == null) ? 0 : tdt_task_svrty_2.hashCode());
		result = prime * result + ((tdt_tech_id == null) ? 0 : tdt_tech_id.hashCode());
		result = prime * result + ((tdt_tsk_sub_cat_id == null) ? 0 : tdt_tsk_sub_cat_id.hashCode());
		result = prime * result + ((tdt_unixdba_number == null) ? 0 : tdt_unixdba_number.hashCode());
		result = prime * result + ((tdt_upd_by == null) ? 0 : tdt_upd_by.hashCode());
		result = prime * result + ((tdt_upd_time == null) ? 0 : tdt_upd_time.hashCode());
		result = prime * result + ((tdt_vend_id == null) ? 0 : tdt_vend_id.hashCode());
		result = prime * result + ((template_flag == null) ? 0 : template_flag.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaskDetails other = (TaskDetails) obj;
		if (Actual_Effort == null) {
			if (other.Actual_Effort != null)
				return false;
		} else if (!Actual_Effort.equals(other.Actual_Effort))
			return false;
		if (Future_Column1 == null) {
			if (other.Future_Column1 != null)
				return false;
		} else if (!Future_Column1.equals(other.Future_Column1))
			return false;
		if (Future_Column2 == null) {
			if (other.Future_Column2 != null)
				return false;
		} else if (!Future_Column2.equals(other.Future_Column2))
			return false;
		if (Future_Column3 == null) {
			if (other.Future_Column3 != null)
				return false;
		} else if (!Future_Column3.equals(other.Future_Column3))
			return false;
		if (Future_Column4 == null) {
			if (other.Future_Column4 != null)
				return false;
		} else if (!Future_Column4.equals(other.Future_Column4))
			return false;
		if (No_Of_Resources == null) {
			if (other.No_Of_Resources != null)
				return false;
		} else if (!No_Of_Resources.equals(other.No_Of_Resources))
			return false;
		if (tdt_EA_tkt == null) {
			if (other.tdt_EA_tkt != null)
				return false;
		} else if (!tdt_EA_tkt.equals(other.tdt_EA_tkt))
			return false;
		if (Double.doubleToLongBits(tdt_act_effort) != Double.doubleToLongBits(other.tdt_act_effort))
			return false;
		if (tdt_act_enddate == null) {
			if (other.tdt_act_enddate != null)
				return false;
		} else if (!tdt_act_enddate.equals(other.tdt_act_enddate))
			return false;
		if (tdt_act_stdate == null) {
			if (other.tdt_act_stdate != null)
				return false;
		} else if (!tdt_act_stdate.equals(other.tdt_act_stdate))
			return false;
		if (tdt_active == null) {
			if (other.tdt_active != null)
				return false;
		} else if (!tdt_active.equals(other.tdt_active))
			return false;
		if (tdt_appln_id == null) {
			if (other.tdt_appln_id != null)
				return false;
		} else if (!tdt_appln_id.equals(other.tdt_appln_id))
			return false;
		if (tdt_assigned_to == null) {
			if (other.tdt_assigned_to != null)
				return false;
		} else if (!tdt_assigned_to.equals(other.tdt_assigned_to))
			return false;
		if (tdt_bus_area_id == null) {
			if (other.tdt_bus_area_id != null)
				return false;
		} else if (!tdt_bus_area_id.equals(other.tdt_bus_area_id))
			return false;
		if (tdt_bus_unit_id == null) {
			if (other.tdt_bus_unit_id != null)
				return false;
		} else if (!tdt_bus_unit_id.equals(other.tdt_bus_unit_id))
			return false;
		if (tdt_ccb_num == null) {
			if (other.tdt_ccb_num != null)
				return false;
		} else if (!tdt_ccb_num.equals(other.tdt_ccb_num))
			return false;
		if (tdt_ccb_num_2 == null) {
			if (other.tdt_ccb_num_2 != null)
				return false;
		} else if (!tdt_ccb_num_2.equals(other.tdt_ccb_num_2))
			return false;
		if (tdt_change_related == null) {
			if (other.tdt_change_related != null)
				return false;
		} else if (!tdt_change_related.equals(other.tdt_change_related))
			return false;
		if (tdt_configurable_item == null) {
			if (other.tdt_configurable_item != null)
				return false;
		} else if (!tdt_configurable_item.equals(other.tdt_configurable_item))
			return false;
		if (tdt_defect_id == null) {
			if (other.tdt_defect_id != null)
				return false;
		} else if (!tdt_defect_id.equals(other.tdt_defect_id))
			return false;
		if (tdt_eng_sub_cat_id == null) {
			if (other.tdt_eng_sub_cat_id != null)
				return false;
		} else if (!tdt_eng_sub_cat_id.equals(other.tdt_eng_sub_cat_id))
			return false;
		if (tdt_engmt_id == null) {
			if (other.tdt_engmt_id != null)
				return false;
		} else if (!tdt_engmt_id.equals(other.tdt_engmt_id))
			return false;
		if (tdt_esc_reason == null) {
			if (other.tdt_esc_reason != null)
				return false;
		} else if (!tdt_esc_reason.equals(other.tdt_esc_reason))
			return false;
		if (tdt_esc_time == null) {
			if (other.tdt_esc_time != null)
				return false;
		} else if (!tdt_esc_time.equals(other.tdt_esc_time))
			return false;
		if (tdt_esc_time_onsite == null) {
			if (other.tdt_esc_time_onsite != null)
				return false;
		} else if (!tdt_esc_time_onsite.equals(other.tdt_esc_time_onsite))
			return false;
		if (tdt_esc_to_cvs == null) {
			if (other.tdt_esc_to_cvs != null)
				return false;
		} else if (!tdt_esc_to_cvs.equals(other.tdt_esc_to_cvs))
			return false;
		if (tdt_esc_to_onsite_id == null) {
			if (other.tdt_esc_to_onsite_id != null)
				return false;
		} else if (!tdt_esc_to_onsite_id.equals(other.tdt_esc_to_onsite_id))
			return false;
		if (tdt_event_notif_dt == null) {
			if (other.tdt_event_notif_dt != null)
				return false;
		} else if (!tdt_event_notif_dt.equals(other.tdt_event_notif_dt))
			return false;
		if (tdt_ext_sys_id == null) {
			if (other.tdt_ext_sys_id != null)
				return false;
		} else if (!tdt_ext_sys_id.equals(other.tdt_ext_sys_id))
			return false;
		if (tdt_freeze == null) {
			if (other.tdt_freeze != null)
				return false;
		} else if (!tdt_freeze.equals(other.tdt_freeze))
			return false;
		if (tdt_high_level_cause == null) {
			if (other.tdt_high_level_cause != null)
				return false;
		} else if (!tdt_high_level_cause.equals(other.tdt_high_level_cause))
			return false;
		if (tdt_incident_type == null) {
			if (other.tdt_incident_type != null)
				return false;
		} else if (!tdt_incident_type.equals(other.tdt_incident_type))
			return false;
		if (tdt_incidents_count == null) {
			if (other.tdt_incidents_count != null)
				return false;
		} else if (!tdt_incidents_count.equals(other.tdt_incidents_count))
			return false;
		if (tdt_logged_by == null) {
			if (other.tdt_logged_by != null)
				return false;
		} else if (!tdt_logged_by.equals(other.tdt_logged_by))
			return false;
		if (tdt_niku_flag == null) {
			if (other.tdt_niku_flag != null)
				return false;
		} else if (!tdt_niku_flag.equals(other.tdt_niku_flag))
			return false;
		if (tdt_notice_time == null) {
			if (other.tdt_notice_time != null)
				return false;
		} else if (!tdt_notice_time.equals(other.tdt_notice_time))
			return false;
		if (tdt_outage_related == null) {
			if (other.tdt_outage_related != null)
				return false;
		} else if (!tdt_outage_related.equals(other.tdt_outage_related))
			return false;
		if (tdt_owner_to == null) {
			if (other.tdt_owner_to != null)
				return false;
		} else if (!tdt_owner_to.equals(other.tdt_owner_to))
			return false;
		if (tdt_pblm_desc == null) {
			if (other.tdt_pblm_desc != null)
				return false;
		} else if (!tdt_pblm_desc.equals(other.tdt_pblm_desc))
			return false;
		if (tdt_pblm_soln == null) {
			if (other.tdt_pblm_soln != null)
				return false;
		} else if (!tdt_pblm_soln.equals(other.tdt_pblm_soln))
			return false;
		if (tdt_pln_enddate == null) {
			if (other.tdt_pln_enddate != null)
				return false;
		} else if (!tdt_pln_enddate.equals(other.tdt_pln_enddate))
			return false;
		if (tdt_pln_startdate == null) {
			if (other.tdt_pln_startdate != null)
				return false;
		} else if (!tdt_pln_startdate.equals(other.tdt_pln_startdate))
			return false;
		if (Double.doubleToLongBits(tdt_prjtd_effort) != Double.doubleToLongBits(other.tdt_prjtd_effort))
			return false;
		if (tdt_pvcs_num == null) {
			if (other.tdt_pvcs_num != null)
				return false;
		} else if (!tdt_pvcs_num.equals(other.tdt_pvcs_num))
			return false;
		if (tdt_reason_esc_onsite_id == null) {
			if (other.tdt_reason_esc_onsite_id != null)
				return false;
		} else if (!tdt_reason_esc_onsite_id.equals(other.tdt_reason_esc_onsite_id))
			return false;
		if (tdt_recovery_ccb == null) {
			if (other.tdt_recovery_ccb != null)
				return false;
		} else if (!tdt_recovery_ccb.equals(other.tdt_recovery_ccb))
			return false;
		if (tdt_recovery_sol == null) {
			if (other.tdt_recovery_sol != null)
				return false;
		} else if (!tdt_recovery_sol.equals(other.tdt_recovery_sol))
			return false;
		if (tdt_remediation == null) {
			if (other.tdt_remediation != null)
				return false;
		} else if (!tdt_remediation.equals(other.tdt_remediation))
			return false;
		if (tdt_remediation_req == null) {
			if (other.tdt_remediation_req != null)
				return false;
		} else if (!tdt_remediation_req.equals(other.tdt_remediation_req))
			return false;
		if (tdt_resol_status_id == null) {
			if (other.tdt_resol_status_id != null)
				return false;
		} else if (!tdt_resol_status_id.equals(other.tdt_resol_status_id))
			return false;
		if (tdt_resolution_time == null) {
			if (other.tdt_resolution_time != null)
				return false;
		} else if (!tdt_resolution_time.equals(other.tdt_resolution_time))
			return false;
		if (tdt_root_cause_no == null) {
			if (other.tdt_root_cause_no != null)
				return false;
		} else if (!tdt_root_cause_no.equals(other.tdt_root_cause_no))
			return false;
		if (tdt_sen_count == null) {
			if (other.tdt_sen_count != null)
				return false;
		} else if (!tdt_sen_count.equals(other.tdt_sen_count))
			return false;
		if (tdt_shift == null) {
			if (other.tdt_shift != null)
				return false;
		} else if (!tdt_shift.equals(other.tdt_shift))
			return false;
		if (tdt_task_cat_id == null) {
			if (other.tdt_task_cat_id != null)
				return false;
		} else if (!tdt_task_cat_id.equals(other.tdt_task_cat_id))
			return false;
		if (tdt_task_id == null) {
			if (other.tdt_task_id != null)
				return false;
		} else if (!tdt_task_id.equals(other.tdt_task_id))
			return false;
		if (tdt_task_svrty == null) {
			if (other.tdt_task_svrty != null)
				return false;
		} else if (!tdt_task_svrty.equals(other.tdt_task_svrty))
			return false;
		if (tdt_task_svrty_2 == null) {
			if (other.tdt_task_svrty_2 != null)
				return false;
		} else if (!tdt_task_svrty_2.equals(other.tdt_task_svrty_2))
			return false;
		if (tdt_tech_id == null) {
			if (other.tdt_tech_id != null)
				return false;
		} else if (!tdt_tech_id.equals(other.tdt_tech_id))
			return false;
		if (tdt_tsk_sub_cat_id == null) {
			if (other.tdt_tsk_sub_cat_id != null)
				return false;
		} else if (!tdt_tsk_sub_cat_id.equals(other.tdt_tsk_sub_cat_id))
			return false;
		if (tdt_unixdba_number == null) {
			if (other.tdt_unixdba_number != null)
				return false;
		} else if (!tdt_unixdba_number.equals(other.tdt_unixdba_number))
			return false;
		if (tdt_upd_by == null) {
			if (other.tdt_upd_by != null)
				return false;
		} else if (!tdt_upd_by.equals(other.tdt_upd_by))
			return false;
		if (tdt_upd_time == null) {
			if (other.tdt_upd_time != null)
				return false;
		} else if (!tdt_upd_time.equals(other.tdt_upd_time))
			return false;
		if (tdt_vend_id == null) {
			if (other.tdt_vend_id != null)
				return false;
		} else if (!tdt_vend_id.equals(other.tdt_vend_id))
			return false;
		if (template_flag == null) {
			if (other.template_flag != null)
				return false;
		} else if (!template_flag.equals(other.template_flag))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TaskDetails [tdt_task_id=" + tdt_task_id + ", tdt_appln_id=" + tdt_appln_id + ", tdt_tech_id="
				+ tdt_tech_id + ", tdt_task_cat_id=" + tdt_task_cat_id + ", tdt_tsk_sub_cat_id=" + tdt_tsk_sub_cat_id
				+ ", tdt_eng_sub_cat_id=" + tdt_eng_sub_cat_id + ", tdt_EA_tkt=" + tdt_EA_tkt + ", tdt_pvcs_num="
				+ tdt_pvcs_num + ", tdt_task_svrty=" + tdt_task_svrty + ", tdt_pblm_desc=" + tdt_pblm_desc
				+ ", tdt_logged_by=" + tdt_logged_by + ", tdt_resol_status_id=" + tdt_resol_status_id
				+ ", tdt_pln_startdate=" + tdt_pln_startdate + ", tdt_pln_enddate=" + tdt_pln_enddate
				+ ", tdt_act_stdate=" + tdt_act_stdate + ", tdt_act_enddate=" + tdt_act_enddate + ", tdt_prjtd_effort="
				+ tdt_prjtd_effort + ", tdt_act_effort=" + tdt_act_effort + ", tdt_pblm_soln=" + tdt_pblm_soln
				+ ", tdt_upd_by=" + tdt_upd_by + ", tdt_upd_time=" + tdt_upd_time + ", tdt_niku_flag=" + tdt_niku_flag
				+ ", tdt_event_notif_dt=" + tdt_event_notif_dt + ", tdt_ext_sys_id=" + tdt_ext_sys_id
				+ ", tdt_notice_time=" + tdt_notice_time + ", tdt_shift=" + tdt_shift + ", tdt_assigned_to="
				+ tdt_assigned_to + ", tdt_incident_type=" + tdt_incident_type + ", tdt_configurable_item="
				+ tdt_configurable_item + ", tdt_change_related=" + tdt_change_related + ", tdt_ccb_num=" + tdt_ccb_num
				+ ", tdt_outage_related=" + tdt_outage_related + ", tdt_esc_to_cvs=" + tdt_esc_to_cvs
				+ ", tdt_esc_time=" + tdt_esc_time + ", tdt_esc_reason=" + tdt_esc_reason + ", tdt_resolution_time="
				+ tdt_resolution_time + ", tdt_owner_to=" + tdt_owner_to + ", tdt_remediation=" + tdt_remediation
				+ ", tdt_ccb_num_2=" + tdt_ccb_num_2 + ", tdt_task_svrty_2=" + tdt_task_svrty_2 + ", tdt_recovery_sol="
				+ tdt_recovery_sol + ", tdt_root_cause_no=" + tdt_root_cause_no + ", tdt_engmt_id=" + tdt_engmt_id
				+ ", tdt_bus_unit_id=" + tdt_bus_unit_id + ", tdt_bus_area_id=" + tdt_bus_area_id
				+ ", tdt_recovery_ccb=" + tdt_recovery_ccb + ", tdt_remediation_req=" + tdt_remediation_req
				+ ", tdt_active=" + tdt_active + ", tdt_freeze=" + tdt_freeze + ", tdt_high_level_cause="
				+ tdt_high_level_cause + ", template_flag=" + template_flag + ", tdt_incidents_count="
				+ tdt_incidents_count + ", tdt_sen_count=" + tdt_sen_count + ", tdt_vend_id=" + tdt_vend_id
				+ ", tdt_esc_to_onsite_id=" + tdt_esc_to_onsite_id + ", tdt_reason_esc_onsite_id="
				+ tdt_reason_esc_onsite_id + ", tdt_esc_time_onsite=" + tdt_esc_time_onsite + ", tdt_unixdba_number="
				+ tdt_unixdba_number + ", tdt_defect_id=" + tdt_defect_id + ", Actual_Effort=" + Actual_Effort
				+ ", No_Of_Resources=" + No_Of_Resources + ", Future_Column1=" + Future_Column1 + ", Future_Column2="
				+ Future_Column2 + ", Future_Column3=" + Future_Column3 + ", Future_Column4=" + Future_Column4 + "]";
	}

}
