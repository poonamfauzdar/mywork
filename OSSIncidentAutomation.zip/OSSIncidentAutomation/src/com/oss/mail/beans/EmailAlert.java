package com.oss.mail.beans;

public class EmailAlert {

	private String receivedDate;
	private String from;
	private String alertString;

	public EmailAlert() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmailAlert(String receivedDate, String from, String alertString) {
		super();
		this.receivedDate = receivedDate;
		this.from = from;
		this.alertString = alertString;
	}

	public String getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getAlertString() {
		return alertString;
	}

	public void setAlertString(String alertString) {
		this.alertString = alertString;
	}

	@Override
	public String toString() {
		return "EmailAlert [receivedDate=" + receivedDate + ", from=" + from + ", alertString=" + alertString + "]";
	}

}
