package com.oss.mail.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "task_event_dtls", schema = "ASM_OSS.dbo") // PRODUCTION
// @Table(name = "[task_event_dtls]", schema = "[ASMDB004].[dbo]")//DEVLOPMENT
public class TaskEventDetails {

	@Id
	@Column(name = "ted_task_id")
	private Integer ted_task_id;
	@Column(name = "ted_event_type_id")
	private Integer ted_event_type_id;
	@Column(name = "ted_event_root_cause_id")
	private Integer ted_event_root_cause_id;
	@Column(name = "ted_event_occur_no")
	private Integer ted_event_occur_no;
	@Column(name = "ted_event_root_cause_desc")
	private String ted_event_root_cause_desc;
	@Column(name = "ted_event_notif_dt")
	private String ted_event_notif_dt;
	@Column(name = "ted_event_rec_status_id")
	private Integer ted_event_rec_status_id;
	@Column(name = "ted_event_rec_stdate")
	private String ted_event_rec_stdate;
	@Column(name = "ted_event_rec_enddate")
	private String ted_event_rec_enddate;
	@Column(name = "ted_event_rec_soln")
	private String ted_event_rec_soln;
	@Column(name = "ted_event_srv_lvl")
	private String ted_event_srv_lvl;
	@Column(name = "ted_event_esc_is")
	private String ted_event_esc_is;
	@Column(name = "ted_event_esc_onsite")
	private String ted_event_esc_onsite;
	@Column(name = "ted_event_buss_impact")
	private String ted_event_buss_impact;
	@Column(name = "ted_event_cust_impact")
	private String ted_event_cust_impact;
	@Column(name = "ted_upd_by")
	private String ted_upd_by;
	@Column(name = "ted_upd_time")
	private String ted_upd_time;
	@Column(name = "ted_vend_id")
	private Integer ted_vend_id;

	public TaskEventDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TaskEventDetails(Integer ted_task_id, Integer ted_event_type_id, Integer ted_event_root_cause_id,
			Integer ted_event_occur_no, String ted_event_root_cause_desc, String ted_event_notif_dt,
			Integer ted_event_rec_status_id, String ted_event_rec_stdate, String ted_event_rec_enddate,
			String ted_event_rec_soln, String ted_event_srv_lvl, String ted_event_esc_is, String ted_event_esc_onsite,
			String ted_event_buss_impact, String ted_event_cust_impact, String ted_upd_by, String ted_upd_time,
			Integer ted_vend_id) {
		super();
		this.ted_task_id = ted_task_id;
		this.ted_event_type_id = ted_event_type_id;
		this.ted_event_root_cause_id = ted_event_root_cause_id;
		this.ted_event_occur_no = ted_event_occur_no;
		this.ted_event_root_cause_desc = ted_event_root_cause_desc;
		this.ted_event_notif_dt = ted_event_notif_dt;
		this.ted_event_rec_status_id = ted_event_rec_status_id;
		this.ted_event_rec_stdate = ted_event_rec_stdate;
		this.ted_event_rec_enddate = ted_event_rec_enddate;
		this.ted_event_rec_soln = ted_event_rec_soln;
		this.ted_event_srv_lvl = ted_event_srv_lvl;
		this.ted_event_esc_is = ted_event_esc_is;
		this.ted_event_esc_onsite = ted_event_esc_onsite;
		this.ted_event_buss_impact = ted_event_buss_impact;
		this.ted_event_cust_impact = ted_event_cust_impact;
		this.ted_upd_by = ted_upd_by;
		this.ted_upd_time = ted_upd_time;
		this.ted_vend_id = ted_vend_id;
	}

	public Integer getTed_task_id() {
		return ted_task_id;
	}

	public void setTed_task_id(Integer ted_task_id) {
		this.ted_task_id = ted_task_id;
	}

	public Integer getTed_event_type_id() {
		return ted_event_type_id;
	}

	public void setTed_event_type_id(Integer ted_event_type_id) {
		this.ted_event_type_id = ted_event_type_id;
	}

	public Integer getTed_event_root_cause_id() {
		return ted_event_root_cause_id;
	}

	public void setTed_event_root_cause_id(Integer ted_event_root_cause_id) {
		this.ted_event_root_cause_id = ted_event_root_cause_id;
	}

	public Integer getTed_event_occur_no() {
		return ted_event_occur_no;
	}

	public void setTed_event_occur_no(Integer ted_event_occur_no) {
		this.ted_event_occur_no = ted_event_occur_no;
	}

	public String getTed_event_root_cause_desc() {
		return ted_event_root_cause_desc;
	}

	public void setTed_event_root_cause_desc(String ted_event_root_cause_desc) {
		this.ted_event_root_cause_desc = ted_event_root_cause_desc;
	}

	public String getTed_event_notif_dt() {
		return ted_event_notif_dt;
	}

	public void setTed_event_notif_dt(String ted_event_notif_dt) {
		this.ted_event_notif_dt = ted_event_notif_dt;
	}

	public Integer getTed_event_rec_status_id() {
		return ted_event_rec_status_id;
	}

	public void setTed_event_rec_status_id(Integer ted_event_rec_status_id) {
		this.ted_event_rec_status_id = ted_event_rec_status_id;
	}

	public String getTed_event_rec_stdate() {
		return ted_event_rec_stdate;
	}

	public void setTed_event_rec_stdate(String ted_event_rec_stdate) {
		this.ted_event_rec_stdate = ted_event_rec_stdate;
	}

	public String getTed_event_rec_enddate() {
		return ted_event_rec_enddate;
	}

	public void setTed_event_rec_enddate(String ted_event_rec_enddate) {
		this.ted_event_rec_enddate = ted_event_rec_enddate;
	}

	public String getTed_event_rec_soln() {
		return ted_event_rec_soln;
	}

	public void setTed_event_rec_soln(String ted_event_rec_soln) {
		this.ted_event_rec_soln = ted_event_rec_soln;
	}

	public String getTed_event_srv_lvl() {
		return ted_event_srv_lvl;
	}

	public void setTed_event_srv_lvl(String ted_event_srv_lvl) {
		this.ted_event_srv_lvl = ted_event_srv_lvl;
	}

	public String getTed_event_esc_is() {
		return ted_event_esc_is;
	}

	public void setTed_event_esc_is(String ted_event_esc_is) {
		this.ted_event_esc_is = ted_event_esc_is;
	}

	public String getTed_event_esc_onsite() {
		return ted_event_esc_onsite;
	}

	public void setTed_event_esc_onsite(String ted_event_esc_onsite) {
		this.ted_event_esc_onsite = ted_event_esc_onsite;
	}

	public String getTed_event_buss_impact() {
		return ted_event_buss_impact;
	}

	public void setTed_event_buss_impact(String ted_event_buss_impact) {
		this.ted_event_buss_impact = ted_event_buss_impact;
	}

	public String getTed_event_cust_impact() {
		return ted_event_cust_impact;
	}

	public void setTed_event_cust_impact(String ted_event_cust_impact) {
		this.ted_event_cust_impact = ted_event_cust_impact;
	}

	public String getTed_upd_by() {
		return ted_upd_by;
	}

	public void setTed_upd_by(String ted_upd_by) {
		this.ted_upd_by = ted_upd_by;
	}

	public String getTed_upd_time() {
		return ted_upd_time;
	}

	public void setTed_upd_time(String ted_upd_time) {
		this.ted_upd_time = ted_upd_time;
	}

	public Integer getTed_vend_id() {
		return ted_vend_id;
	}

	public void setTed_vend_id(Integer ted_vend_id) {
		this.ted_vend_id = ted_vend_id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ted_event_buss_impact == null) ? 0 : ted_event_buss_impact.hashCode());
		result = prime * result + ((ted_event_cust_impact == null) ? 0 : ted_event_cust_impact.hashCode());
		result = prime * result + ((ted_event_esc_is == null) ? 0 : ted_event_esc_is.hashCode());
		result = prime * result + ((ted_event_esc_onsite == null) ? 0 : ted_event_esc_onsite.hashCode());
		result = prime * result + ((ted_event_notif_dt == null) ? 0 : ted_event_notif_dt.hashCode());
		result = prime * result + ted_event_occur_no;
		result = prime * result + ((ted_event_rec_enddate == null) ? 0 : ted_event_rec_enddate.hashCode());
		result = prime * result + ((ted_event_rec_soln == null) ? 0 : ted_event_rec_soln.hashCode());
		result = prime * result + ted_event_rec_status_id;
		result = prime * result + ((ted_event_rec_stdate == null) ? 0 : ted_event_rec_stdate.hashCode());
		result = prime * result + ((ted_event_root_cause_desc == null) ? 0 : ted_event_root_cause_desc.hashCode());
		result = prime * result + ted_event_root_cause_id;
		result = prime * result + ((ted_event_srv_lvl == null) ? 0 : ted_event_srv_lvl.hashCode());
		result = prime * result + ted_event_type_id;
		result = prime * result + ted_task_id;
		result = prime * result + ((ted_upd_by == null) ? 0 : ted_upd_by.hashCode());
		result = prime * result + ((ted_upd_time == null) ? 0 : ted_upd_time.hashCode());
		result = prime * result + ted_vend_id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaskEventDetails other = (TaskEventDetails) obj;
		if (ted_event_buss_impact == null) {
			if (other.ted_event_buss_impact != null)
				return false;
		} else if (!ted_event_buss_impact.equals(other.ted_event_buss_impact))
			return false;
		if (ted_event_cust_impact == null) {
			if (other.ted_event_cust_impact != null)
				return false;
		} else if (!ted_event_cust_impact.equals(other.ted_event_cust_impact))
			return false;
		if (ted_event_esc_is == null) {
			if (other.ted_event_esc_is != null)
				return false;
		} else if (!ted_event_esc_is.equals(other.ted_event_esc_is))
			return false;
		if (ted_event_esc_onsite == null) {
			if (other.ted_event_esc_onsite != null)
				return false;
		} else if (!ted_event_esc_onsite.equals(other.ted_event_esc_onsite))
			return false;
		if (ted_event_notif_dt == null) {
			if (other.ted_event_notif_dt != null)
				return false;
		} else if (!ted_event_notif_dt.equals(other.ted_event_notif_dt))
			return false;
		if (ted_event_occur_no != other.ted_event_occur_no)
			return false;
		if (ted_event_rec_enddate == null) {
			if (other.ted_event_rec_enddate != null)
				return false;
		} else if (!ted_event_rec_enddate.equals(other.ted_event_rec_enddate))
			return false;
		if (ted_event_rec_soln == null) {
			if (other.ted_event_rec_soln != null)
				return false;
		} else if (!ted_event_rec_soln.equals(other.ted_event_rec_soln))
			return false;
		if (ted_event_rec_status_id != other.ted_event_rec_status_id)
			return false;
		if (ted_event_rec_stdate == null) {
			if (other.ted_event_rec_stdate != null)
				return false;
		} else if (!ted_event_rec_stdate.equals(other.ted_event_rec_stdate))
			return false;
		if (ted_event_root_cause_desc == null) {
			if (other.ted_event_root_cause_desc != null)
				return false;
		} else if (!ted_event_root_cause_desc.equals(other.ted_event_root_cause_desc))
			return false;
		if (ted_event_root_cause_id != other.ted_event_root_cause_id)
			return false;
		if (ted_event_srv_lvl == null) {
			if (other.ted_event_srv_lvl != null)
				return false;
		} else if (!ted_event_srv_lvl.equals(other.ted_event_srv_lvl))
			return false;
		if (ted_event_type_id != other.ted_event_type_id)
			return false;
		if (ted_task_id != other.ted_task_id)
			return false;
		if (ted_upd_by == null) {
			if (other.ted_upd_by != null)
				return false;
		} else if (!ted_upd_by.equals(other.ted_upd_by))
			return false;
		if (ted_upd_time == null) {
			if (other.ted_upd_time != null)
				return false;
		} else if (!ted_upd_time.equals(other.ted_upd_time))
			return false;
		if (ted_vend_id != other.ted_vend_id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TaskEventDetails [ted_task_id=" + ted_task_id + ", ted_event_type_id=" + ted_event_type_id
				+ ", ted_event_root_cause_id=" + ted_event_root_cause_id + ", ted_event_occur_no=" + ted_event_occur_no
				+ ", ted_event_root_cause_desc=" + ted_event_root_cause_desc + ", ted_event_notif_dt="
				+ ted_event_notif_dt + ", ted_event_rec_status_id=" + ted_event_rec_status_id
				+ ", ted_event_rec_stdate=" + ted_event_rec_stdate + ", ted_event_rec_enddate=" + ted_event_rec_enddate
				+ ", ted_event_rec_soln=" + ted_event_rec_soln + ", ted_event_srv_lvl=" + ted_event_srv_lvl
				+ ", ted_event_esc_is=" + ted_event_esc_is + ", ted_event_esc_onsite=" + ted_event_esc_onsite
				+ ", ted_event_buss_impact=" + ted_event_buss_impact + ", ted_event_cust_impact="
				+ ted_event_cust_impact + ", ted_upd_by=" + ted_upd_by + ", ted_upd_time=" + ted_upd_time
				+ ", ted_vend_id=" + ted_vend_id + "]";
	}

}
