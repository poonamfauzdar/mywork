package com.oss.mail.controller;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.oss.mail.beans.TaskDetails;
import com.oss.mail.quartz.config.QuartzConfig;
import com.oss.mail.service.EmailReadingService;

@RestController
@RequestMapping("/api/incidentAutomation")
public class IncidentsAutomationController {
	static Logger logger = LogManager.getLogger(IncidentsAutomationController.class.getName());

	@Autowired
	EmailReadingService emailReadingService;

	@Autowired
	private QuartzConfig quartzConfig;

	@ResponseBody
	@RequestMapping(value = "/start", method = RequestMethod.GET, headers = "Accept=application/json", produces = "application/json")
	public List<TaskDetails> startEmailProcessing() {
		logger.info("Calling startEmailProcessing()");
		logger.info("Calling readEmails() method from EmailReadingService.");
		return emailReadingService.readEmails();

		// TODo Create service for specific time.
	}

	@ResponseBody
	@RequestMapping(value = "/scheduling/start", method = RequestMethod.GET, headers = "Accept=application/json", produces = "application/json")
	public boolean scheduleStartIncidentAutomation() {
		logger.info("called scheduleStartIncidentAutomation()");
		return quartzConfig.init();
	}

	@ResponseBody
	@RequestMapping(value = "/scheduling/stop", method = RequestMethod.GET, headers = "Accept=application/json", produces = "application/json")
	public boolean scheduleStopIncidentAutomation() {
		logger.info("called scheduleStopIncidentAutomation()");
		return quartzConfig.schdulerPause();
	}
	@ResponseBody
	@RequestMapping(value = "/scheduling/terminate", method = RequestMethod.GET, headers = "Accept=application/json", produces = "application/json")
	public boolean scheduleTerminateIncidentAutomation() {
		logger.info("called scheduleTerminateIncidentAutomation()");
		return quartzConfig.destroy();
	}

	@PostConstruct
	public void init() {
		logger.info("------------------------------------Initializing OSSIncidentAutomation--------------------------");
		logger.info("------------------------------------Developed by Abhishek Saxena--------------------------");
	}

	@PreDestroy
	public void destroy() {
		logger.info(
				"-------------------------------------Stopping OSSIncidentAutomation-------------------------------");
	}

}
