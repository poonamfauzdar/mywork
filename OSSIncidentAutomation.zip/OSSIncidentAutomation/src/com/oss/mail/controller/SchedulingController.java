//package com.oss.mail.controller;
//
//import java.io.InputStream;
//import java.util.Objects;
//import java.util.Properties;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.quartz.CronScheduleBuilder;
//import org.quartz.JobBuilder;
//import org.quartz.JobDetail;
//import org.quartz.JobExecutionContext;
//import org.quartz.JobKey;
//import org.quartz.Scheduler;
//import org.quartz.SchedulerException;
//import org.quartz.Trigger;
//import org.quartz.TriggerBuilder;
//import org.quartz.impl.matchers.GroupMatcher;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import com.oss.mail.quartz.job.IncidentAutomationJob;
//
//@Component
//public class SchedulingController {
//	static Logger logger = LogManager.getLogger(SchedulingController.class.getName());
//	Properties prop = new Properties();
//	ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
//	InputStream input = classLoader.getResourceAsStream("app.properties");
//
//	private Scheduler scheduler;
//	
//	public SchedulingController(@Autowired Scheduler scheduler){
//		this.scheduler=scheduler;
//	}
//	
//	public boolean scheduleAutomation(){
//		try{
//			prop.load(input);
//			String scheduleTime=prop.getProperty("Quartz.job.IncidentAutomationJob.cron");
//			
//			logger.info("Creating job with name : incidentAutomationJob");
//			JobDetail incidentAutomationJob = JobBuilder.newJob(IncidentAutomationJob.class)
//					.withIdentity("incidentAutomationJob", "group1").build();
//			logger.info("Creating trigger with name : triggerIncidentAutomationJob");
//			Trigger triggerIncidentAutomationJob = TriggerBuilder
//					.newTrigger()
//					.withIdentity("incidentAutomationJob", "group1")
//					.startNow()
//					.withSchedule(
//						CronScheduleBuilder.cronSchedule(scheduleTime))
//					.build();
//			if(!scheduler.checkExists(findJobKey("incidentAutomationJob", scheduler)))
//			{
//			logger.info("Scheduler is scheduling job");
//			scheduler.scheduleJob(incidentAutomationJob, triggerIncidentAutomationJob);
//			}else{
//				logger.info("Job is already scheduled.");
//			}
//			logger.info("Scheduler is starting.");
//			scheduler.start();
//			logger.info("Scheduler has started");
//			
//			return true;
//		}catch(Exception e){
//			logger.error(e.getMessage(),e);
//		}
//		return false;
//	}
//	
//	public JobKey findJobKey(String jobName, Scheduler scheduler) throws SchedulerException {
//	    // Check running jobs first
//	    for (JobExecutionContext runningJob : scheduler.getCurrentlyExecutingJobs()) {
//	        if (Objects.equals(jobName, runningJob.getJobDetail().getKey().getName())) {
//	            return runningJob.getJobDetail().getKey();
//	        }
//	    }
//	    // Check all jobs if not found
//	    for (String groupName : scheduler.getJobGroupNames()) {
//	        for (JobKey jobKey : scheduler.getJobKeys(GroupMatcher.jobGroupEquals(groupName))) {
//	            if (Objects.equals(jobName, jobKey.getName())) {
//	                return jobKey;
//	            }
//	        }
//	    }
//		return null;
//	}
//	
//	public void init(){
//		logger.info("--------------------------------INITIALIZING SCHEDULING---------------------");
//		scheduleAutomation();
//	}
//	
//	public boolean destroy(){
//		logger.info("---------------------------------STOPPING SCHEDULING-------------------------");
//		try {
//			scheduler.shutdown(true);
//			return true;
//		} catch (SchedulerException e) {
//			logger.error(e.getMessage(),e);
//		}
//		catch(Exception e){
//			logger.error(e.getMessage(),e);
//		}
//		return false;
//	}
//}
