package com.oss.mail.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.oss.mail.beans.TaskDetails;
import com.oss.mail.beans.TaskEventDetails;
import com.oss.mail.service.TaskDetailsService;
import com.oss.mail.service.TaskEventDetailsService;

@RestController
@RequestMapping("/api")
public class DBTablesController {

	@Autowired
	private TaskDetailsService taskDetailsService;

	@Autowired
	private TaskEventDetailsService taskEventDetailsService;

	// For TaskDetails
	@ResponseBody
	@RequestMapping(value = "/addTaskDetails/", method = RequestMethod.POST, headers = "Accept=application/json", produces = "application/json")
	public TaskDetails addTaskDetails(@RequestBody TaskDetails taskDetails) {
		System.out.println("Called addTaskDetails()");
		return taskDetailsService.addTaskDetails(taskDetails);
	}

	@ResponseBody
	@RequestMapping(value = "/updateTaskDetails/", method = RequestMethod.PUT, headers = "Accept=application/json", produces = "application/json")
	public TaskDetails updateTaskDetails(@RequestBody TaskDetails taskDetails) {
		System.out.println("Called updateTaskDetails()");
		return taskDetailsService.updateTaskDetails(taskDetails);
	}

	@ResponseBody
	@RequestMapping(value = "/removeTaskDetails/{id}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public void removeTaskDetails(@PathVariable("id") Integer id) {
		System.out.println("Called removeTaskDetails for id :" + id);
		taskDetailsService.removeTaskDetails(id);
	}

	@ResponseBody
	@RequestMapping(value = "/listTaskDetails/getById/{id}", method = RequestMethod.GET, headers = "Accept=application/json", produces = "application/json")
	public TaskDetails getTaskDetailsById(@PathVariable("id") Integer id) {
		System.out.println("Called getTaskDetailsById for id :" + id);
		return taskDetailsService.getTaskDetailsById(id);
	}

	// For TaskEventDetails

	@ResponseBody
	@RequestMapping(value = "/addTaskEventDetails/", method = RequestMethod.POST, headers = "Accept=application/json", produces = "application/json")
	public TaskEventDetails addTaskEventDetails(@RequestBody TaskEventDetails taskEventDetails) {
		System.out.println("Called addTaskEventDetails()");
		return taskEventDetailsService.addTaskEventDetails(taskEventDetails);
	}

	@ResponseBody
	@RequestMapping(value = "/updateTaskEventDetails/", method = RequestMethod.PUT, headers = "Accept=application/json", produces = "application/json")
	public TaskEventDetails updateTaskEventDetails(@RequestBody TaskEventDetails taskEventDetails) {
		System.out.println("Called updateTaskEventDetails()");
		return taskEventDetailsService.updateTaskEventDetails(taskEventDetails);
	}

	@ResponseBody
	@RequestMapping(value = "/removeTaskEventDetails/{id}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public void removeTaskEventDetails(@PathVariable("id") Integer id) {
		System.out.println("Called removeTaskEventDetails for id :" + id);
		taskEventDetailsService.removeTaskEventDetails(id);
	}

	@ResponseBody
	@RequestMapping(value = "/listTaskEventDetails/getById/{id}", method = RequestMethod.GET, headers = "Accept=application/json", produces = "application/json")
	public TaskEventDetails getTaskEventDetailsById(@PathVariable("id") Integer id) {
		System.out.println("Called getTaskEventDetailsById for id :" + id);
		return taskEventDetailsService.getTaskEventDetailsById(id);
	}
}
